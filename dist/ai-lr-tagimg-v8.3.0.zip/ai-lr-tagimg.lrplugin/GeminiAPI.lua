--[[----------------------------------------------------------------------------

 AI Image Tagger
 Copyright 2025 Anand's Photography
 Updated for Lightroom Classic 2024 and Gemini AI API

--------------------------------------------------------------------------------

GeminiAPI.lua

------------------------------------------------------------------------------]]

local LrHttp = import "LrHttp"
local LrDate = import "LrDate"
local LrStringUtils = import "LrStringUtils"
local LrPrefs = import "LrPrefs"
local LrPasswords = import "LrPasswords"
local LrTasks = import "LrTasks"

local JSON = require "JSON"
require "Logger"
local AICommon = require "AICommon"

--------------------------------------------------------------------------------
-- Gemini AI API

GeminiAPI = { }

local httpContentType = "Content-Type"
local httpAccept = "Accept"

local mimeTypeJson = "application/json"

local keyApiKey = "GeminiAI.ApiKey"

local serviceBaseUri = "https://generativelanguage.googleapis.com/v1beta"

--------------------------------------------------------------------------------

-- Get model from preferences (defaults to flash in AiTaggerInit.lua)
local function getServiceModel()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.geminiModel or "gemini-2.5-flash"
end
local serviceMaxRetries = 2

--------------------------------------------------------------------------------

function GeminiAPI.getVersions()
	local versions = { }

	versions.gemini = {
		version = "Gemini AI API v1beta (2024)",
	}

	return versions
end

function GeminiAPI.storeApiKey( apiKey )
	math.randomseed( LrDate.currentTime() )
	local salt = tostring( math.random() * 100000 )
	local prefs = LrPrefs.prefsForPlugin()
	prefs.salt = salt
	LrPasswords.store( keyApiKey, apiKey, salt )
end

function GeminiAPI.clearApiKey()
	local prefs = LrPrefs.prefsForPlugin()
	prefs.salt = nil
	LrPasswords.store( keyApiKey, "" )
end

function GeminiAPI.getApiKey()
	local prefs = LrPrefs.prefsForPlugin()
	local salt = prefs.salt
	return LrPasswords.retrieve( keyApiKey, salt )
end

function GeminiAPI.hasApiKey()
	local apiKey = GeminiAPI.getApiKey()
	return apiKey ~= nil and apiKey ~= ""
end

--------------------------------------------------------------------------------

function GeminiAPI.analyze( fileName, photo, photoObject )
	local attempts = 0
	while attempts <= serviceMaxRetries do
		-- Add exponential backoff delay for retries to avoid overwhelming API
		if attempts > 0 then
			local delay = math.min(2 ^ attempts, 8) -- Exponential backoff: 2s, 4s, 8s max
			logger:infof("GeminiAPI: Retry attempt %d for %s after %d second delay", attempts, fileName, delay)
			LrTasks.sleep(delay)
		end

		local apiKey = GeminiAPI.getApiKey()
		if apiKey and apiKey ~= "" then
			local reqHeaders = {
				{ field = httpContentType, value = mimeTypeJson },
				{ field = httpAccept, value = mimeTypeJson },
			}

			-- Build prompt with optional metadata
			local prompt = AICommon.getAnalysisPrompt()
			prompt = AICommon.appendMetadataToPrompt( prompt, photoObject )

			-- Create the request body for Gemini API
			local reqBody = JSON:encode {
				contents = {
					{
						parts = {
							{
								text = prompt
							},
							{
								inline_data = {
									mime_type = "image/jpeg",
									data = LrStringUtils.encodeBase64( photo )
								}
							}
						}
					}
				},
				generationConfig = {
					responseMimeType = "application/json",
					temperature = 0.4,
					topP = 0.8,
					maxOutputTokens = 4096
				}
			}

			local serviceUri = string.format( "%s/models/%s:generateContent?key=%s", serviceBaseUri, getServiceModel(), apiKey )

			-- Make HTTP call
			local resBody, resHeaders = LrHttp.post( serviceUri, reqBody, reqHeaders )

			if not resBody then
				local errorMsg = "Network request failed: no response received"
				if resHeaders and resHeaders.error then
					errorMsg = string.format( "Network error: %s", resHeaders.error.name or "unknown error" )
				end

				if attempts < serviceMaxRetries then
					logger:warnf( "GeminiAPI: %s (attempt %d/%d)", errorMsg, attempts + 1, serviceMaxRetries + 1 )
				else
					logger:errorf( "GeminiAPI: %s", errorMsg )
					return { status = false, message = errorMsg }
				end
			elseif resBody then

				local resJson = JSON:decode( resBody )
				if not resJson then
					logger:errorf( "GeminiAPI: Failed to parse JSON response" )
					logger:infof( "GeminiAPI: Raw response: %s", resBody )
					return { status = false, message = "Failed to parse JSON response" }
				end


				if resHeaders.status == 401 then
					logger:warnf( "GeminiAPI: authorization failure, invalid API key" )
					return { status = false, message = "Invalid API key" }
				elseif resHeaders.status == 200 then
					local results = { status = true }

					-- Parse the response

					if resJson.candidates and #resJson.candidates > 0 then
						local candidate = resJson.candidates[1]

						-- Check finish reason for issues
						if candidate.finishReason then
							if candidate.finishReason == "MAX_TOKENS" then
								logger:warnf( "GeminiAPI: Response truncated due to token limit (MAX_TOKENS)" )
								return { status = false, message = "Response truncated due to token limit. Try a shorter prompt or increase maxOutputTokens." }
							elseif candidate.finishReason == "SAFETY" then
								logger:warnf( "GeminiAPI: Response blocked by safety filters" )
								return { status = false, message = "Response blocked by safety filters" }
							elseif candidate.finishReason ~= "STOP" then
								logger:warnf( "GeminiAPI: Unexpected finish reason: %s", candidate.finishReason )
							end
						end

						-- Extract response text from various possible formats
						local responseText = nil

						-- Method 1: Standard parts array format
						if candidate.content and candidate.content.parts and #candidate.content.parts > 0 then
							for _, part in ipairs(candidate.content.parts) do
								if part.text and part.text ~= "" then
									responseText = part.text
									break
								end
							end
						end

						-- Method 2: Direct content.text field
						if not responseText and candidate.content and candidate.content.text then
							responseText = candidate.content.text
						end

						-- Method 3: Look for any text field in content
						if not responseText and candidate.content then
							for key, value in pairs(candidate.content) do
								if type(value) == "string" and value ~= "" and key:lower():find("text") then
									responseText = value
									break
								end
							end
						end

						-- Method 4: Look for text field directly in candidate
						if not responseText and candidate.text then
							responseText = candidate.text
						end

						-- Method 5: Look for any text field at candidate level
						if not responseText then
							for key, value in pairs(candidate) do
								if type(value) == "string" and value ~= "" and key:lower():find("text") then
									responseText = value
									break
								end
							end
						end

						if responseText then

							-- Validate JSON completeness before parsing
							local jsonStart = responseText:find("{")
							local jsonEnd = responseText:find("}[^}]*$")

							if not jsonStart then
								logger:errorf( "GeminiAPI: No JSON object found in response" )
								responseText = nil
							elseif not jsonEnd then
								logger:warnf( "GeminiAPI: JSON appears incomplete, attempting to fix" )

								local fixed = false
								local lastQuote = responseText:match('.*"([^"]*)')
								if lastQuote then
									local beforeQuote = responseText:match('(.*)"[^"]*$')
									if beforeQuote then
										responseText = beforeQuote .. '""}'
										fixed = true
									end
								end

								if not fixed then
									local lastComma = responseText:reverse():find(",")
									if lastComma then
										local truncateAt = string.len(responseText) - lastComma + 1
										responseText = responseText:sub(1, truncateAt - 1) .. "}"
									else
										local lastColon = responseText:reverse():find(":")
										if lastColon then
											local truncateAt = string.len(responseText) - lastColon + 1
											responseText = responseText:sub(1, truncateAt - 1) .. '""}'
										else
											responseText = responseText .. '""}'
										end
									end
								end
							end

							if responseText then
								local success, analysisResult = pcall(function()
									return JSON:decode( responseText )
								end)

								if not success then
									logger:infof( "GeminiAPI: Initial JSON parsing failed, attempting robust extraction..." )
									local validJson = AICommon.extractValidJSON( responseText )
									if validJson then
										logger:infof( "GeminiAPI: Extracted valid JSON using brace matching" )
										success, analysisResult = pcall(function()
											return JSON:decode( validJson )
										end)
									end
								end

								if not success then
									logger:errorf( "GeminiAPI: JSON parsing failed: %s", tostring(analysisResult) )
									analysisResult = nil
								end

								if analysisResult then
									local parsed = AICommon.buildAnalysisResult( analysisResult )
									results.title = parsed.title
									results.caption = parsed.caption
									results.headline = parsed.headline
									results.instructions = parsed.instructions
									results.copyright = parsed.copyright
									results.location = parsed.location
									results.keywords = parsed.keywords
								else
									local empty = AICommon.emptyResults()
									results.title = empty.title
									results.caption = empty.caption
									results.headline = empty.headline
									results.instructions = empty.instructions
									results.copyright = empty.copyright
									results.location = empty.location
									results.keywords = empty.keywords
								end
							else
								-- responseText was invalidated (e.g. no JSON found)
								local empty = AICommon.emptyResults()
								results.title = empty.title
								results.caption = empty.caption
								results.headline = empty.headline
								results.instructions = empty.instructions
								results.copyright = empty.copyright
								results.location = empty.location
								results.keywords = empty.keywords
							end
						else
							local empty = AICommon.emptyResults()
							results.title = empty.title
							results.caption = empty.caption
							results.headline = empty.headline
							results.instructions = empty.instructions
							results.copyright = empty.copyright
							results.location = empty.location
							results.keywords = empty.keywords
						end
					else
						local empty = AICommon.emptyResults()
						results.title = empty.title
						results.caption = empty.caption
						results.headline = empty.headline
						results.instructions = empty.instructions
						results.copyright = empty.copyright
						results.location = empty.location
						results.keywords = empty.keywords
					end

					return results
				else
					local errorMsg = "Unknown error"
					if resJson and resJson.error and resJson.error.message then
						errorMsg = resJson.error.message
					end

					local isRetriable = false
					if resHeaders.status == 429 or resHeaders.status == 503 or
					   (errorMsg and (errorMsg:find("quota") or errorMsg:find("rate limit") or errorMsg:find("retry"))) then
						isRetriable = true
					end

					if isRetriable and attempts < serviceMaxRetries then
						logger:warnf( "GeminiAPI: retriable error on attempt %d/%d: %s", attempts + 1, serviceMaxRetries + 1, errorMsg )
					else
						logger:errorf( "GeminiAPI: analyze API failed: %s", errorMsg )
						return { status = false, message = errorMsg }
					end
				end
			end
		else
			logger:warnf( "GeminiAPI: API key missing" )
			return { status = false, message = "API key missing" }
		end

		attempts = attempts + 1
	end

	return { status = false, message = "Maximum retries exceeded" }
end

-- Batch processing with rate limiting
function GeminiAPI.analyzeBatch( photos, progressCallback )
	return AICommon.analyzeBatch( GeminiAPI.analyze, photos, progressCallback )
end

-- Get default prompt for UI display
function GeminiAPI.getDefaultPrompt()
	return AICommon.getDefaultPrompt()
end

-- Load prompt from text file
function GeminiAPI.loadPromptFromFile( filePath )
	return AICommon.loadPromptFromFile( filePath )
end

-- Get available prompt presets
function GeminiAPI.getPromptPresets()
	return AICommon.getPromptPresets()
end

-- Get preset names for UI dropdown
function GeminiAPI.getPresetNames()
	return AICommon.getPresetNames()
end

-- Get a specific preset by name
function GeminiAPI.getPreset( name )
	return AICommon.getPreset( name )
end
