--[[----------------------------------------------------------------------------

 AI Image Tagger - Shared AI Provider Utilities
 Copyright 2025 Anand's Photography

--------------------------------------------------------------------------------

AICommon.lua
Shared functions used by all AI provider modules (Gemini, OpenAI, Ollama).

------------------------------------------------------------------------------]]

local LrPrefs = import "LrPrefs"
local LrStringUtils = import "LrStringUtils"
local LrTasks = import "LrTasks"

local JSON = require "JSON"
require "Logger"
local PromptPresets = require "PromptPresets"

--------------------------------------------------------------------------------

local AICommon = {}

--------------------------------------------------------------------------------
-- JSON extraction helpers

-- Robust JSON extraction using brace matching
-- Handles malformed JSON by finding the largest valid JSON object
function AICommon.extractValidJSON( text )
	local startPos = string.find(text, "{")
	if not startPos then
		return nil
	end

	local depth = 0
	local inString = false
	local escaped = false
	local endPos = nil

	for i = startPos, string.len(text) do
		local char = string.sub(text, i, i)

		if escaped then
			escaped = false
		elseif char == "\\" then
			escaped = true
		elseif char == '"' and not escaped then
			inString = not inString
		elseif not inString then
			if char == "{" then
				depth = depth + 1
			elseif char == "}" then
				depth = depth - 1
				if depth == 0 then
					endPos = i
					break
				end
			end
		end
	end

	if endPos then
		return string.sub(text, startPos, endPos)
	end

	return nil
end

-- Convert field to string, handling arrays and other types
function AICommon.fieldToString(field)
	if type(field) == "string" then
		return field
	elseif type(field) == "table" then
		if #field > 0 then
			local stringParts = {}
			for _, item in ipairs(field) do
				if type(item) == "string" then
					table.insert(stringParts, item)
				end
			end
			return table.concat(stringParts, " ")
		end
		return ""
	else
		return tostring(field or "")
	end
end

--------------------------------------------------------------------------------
-- Metadata extraction

-- Extract GPS and EXIF metadata from a photo for AI analysis
function AICommon.extractMetadata( photo )
	local metadata = {}

	local gps = photo:getFormattedMetadata( "gps" )
	if gps and gps ~= "" then
		metadata.gps = gps
	end

	local copyright = photo:getFormattedMetadata( "copyright" )
	if copyright and copyright ~= "" then
		metadata.copyright = copyright
	end

	local city = photo:getFormattedMetadata( "city" )
	local stateProvince = photo:getFormattedMetadata( "stateProvince" )
	local country = photo:getFormattedMetadata( "country" )
	local location = photo:getFormattedMetadata( "location" )
	if city or stateProvince or country or location then
		metadata.location = {
			city = city,
			stateProvince = stateProvince,
			country = country,
			location = location
		}
	end

	local cameraMake = photo:getFormattedMetadata( "cameraMake" )
	local cameraModel = photo:getFormattedMetadata( "cameraModel" )
	local lens = photo:getFormattedMetadata( "lens" )
	if cameraMake or cameraModel or lens then
		metadata.camera = {
			make = cameraMake,
			model = cameraModel,
			lens = lens
		}
	end

	local focalLength = photo:getFormattedMetadata( "focalLength" )
	local aperture = photo:getFormattedMetadata( "aperture" )
	local shutterSpeed = photo:getFormattedMetadata( "shutterSpeed" )
	local isoSpeedRating = photo:getFormattedMetadata( "isoSpeedRating" )
	local flash = photo:getFormattedMetadata( "flash" )
	if focalLength or aperture or shutterSpeed or isoSpeedRating or flash then
		metadata.settings = {
			focalLength = focalLength,
			aperture = aperture,
			shutterSpeed = shutterSpeed,
			iso = isoSpeedRating,
			flash = flash
		}
	end

	local dateTimeOriginal = photo:getFormattedMetadata( "dateTimeOriginal" )
	if dateTimeOriginal then
		metadata.datetime = dateTimeOriginal
	end

	local dimensions = photo:getFormattedMetadata( "dimensions" )
	local croppedDimensions = photo:getFormattedMetadata( "croppedDimensions" )
	if dimensions or croppedDimensions then
		metadata.image = {
			dimensions = dimensions,
			croppedDimensions = croppedDimensions
		}
	end

	local keywords = photo:getRawMetadata( "keywords" )
	if keywords and #keywords > 0 then
		local keywordNames = {}
		for _, keyword in ipairs( keywords ) do
			local name = keyword:getName()
			if name and name ~= "" then
				table.insert( keywordNames, name )
			end
		end
		if #keywordNames > 0 then
			metadata.keywords = keywordNames
		end
	end

	if next(metadata) == nil then
		return nil
	end

	return metadata
end

--------------------------------------------------------------------------------
-- Prompt generation

function AICommon.getDefaultPrompt()
	local prefs = LrPrefs.prefsForPlugin()
	local language = prefs.responseLanguage or "English"
	local languageInstruction = ""

	if language ~= "English" then
		languageInstruction = string.format("IMPORTANT: Please respond in %s language. All text fields (title, caption, headline, keywords, instructions, location) should be in %s.\n\n", language, language)
	end

	local keywordInstruction = ""
	local keywordExample = ""
	local keywordFormatNote = ""

	if prefs.useHierarchicalKeywords then
		keywordInstruction = "4. A list of relevant hierarchical keywords organized from broad to specific categories using ' > ' separator (e.g., Nature > Wildlife > Birds, Sports > Team Sports > Football)"
		keywordExample = "\"Nature > Wildlife > Birds, Sports > Team Sports > Football, Photography > Wildlife Photography > Telephoto\""
		keywordFormatNote = "IMPORTANT: The keywords field must be a comma-separated string with hierarchical keywords using ' > ' separators, not an array."
	else
		keywordInstruction = "4. A list of relevant keywords (comma-separated string). Do NOT use hierarchical keywords or separators like ' > '."
		keywordExample = "\"keyword1, keyword2, keyword3\""
		keywordFormatNote = "IMPORTANT: The keywords field must be a comma-separated string, not an array. Do not include hierarchical structures."
	end

	local basePrompt = "Please analyze this photograph and provide:\n1. A short title (2-5 words)\n2. A brief caption (1-2 sentences)\n3. A detailed headline/description (2-3 sentences)\n" .. keywordInstruction .. "\n5. Special instructions for photo editing or usage (if applicable)\n6. Location information (if identifiable landmarks are present)\n\nPlease format your response as JSON with the following structure:\n{\n  \"title\": \"short descriptive title\",\n  \"caption\": \"brief caption here\",\n  \"headline\": \"detailed headline/description here\",\n  \"keywords\": " .. keywordExample .. ",\n  \"instructions\": \"editing suggestions or usage notes\",\n  \"location\": \"location name if identifiable landmarks present\"\n}\n\n" .. keywordFormatNote

	if prefs.useHierarchicalKeywords then
		local hierarchicalInstruction = "\n\nFor hierarchical keywords:\n- Start with broad categories (Nature, Sports, Architecture, Photography)\n- Progress to specific subcategories (Wildlife, Team Sports, Modern Architecture)\n- End with detailed descriptors (Birds, Football, Glass Building)\n- Use ' > ' to separate hierarchy levels\n- Provide 8-12 hierarchical keywords total\n- Examples: \"Nature > Wildlife > Birds > Eagles\", \"Sports > Team Sports > Football\", \"Photography > Portrait Photography > Studio\""
		basePrompt = basePrompt .. hierarchicalInstruction
	end

	return languageInstruction .. basePrompt
end

function AICommon.getAnalysisPrompt()
	local prefs = LrPrefs.prefsForPlugin()
	local language = prefs.responseLanguage or "English"
	local languageInstruction = ""

	if language ~= "English" then
		languageInstruction = string.format("IMPORTANT: Please respond in %s language. All text fields should be in %s.\n\n", language, language)
	end

	local basePrompt = ""
	if prefs.useCustomPrompt and prefs.customPrompt and prefs.customPrompt ~= "" then
		basePrompt = languageInstruction .. prefs.customPrompt
	else
		basePrompt = AICommon.getDefaultPrompt()
	end

	-- Add hierarchical keyword instructions if enabled, regardless of custom/default prompt
	if prefs.useHierarchicalKeywords then
		local hierarchicalAddendum = "\n\nIMPORTANT: For keywords, please provide hierarchical keywords organized from broad to specific categories using ' > ' separator (e.g., Nature > Wildlife > Birds, Sports > Team Sports > Football). The keywords field must be a comma-separated string with hierarchical keywords using ' > ' separators, not an array.\n\nFor hierarchical keywords:\n- Start with broad categories (Nature, Sports, Architecture, Photography)\n- Progress to specific subcategories (Wildlife, Team Sports, Modern Architecture)\n- End with detailed descriptors (Birds, Football, Glass Building)\n- Use ' > ' to separate hierarchy levels\n- Provide 8-12 hierarchical keywords total\n- Examples: \"Nature > Wildlife > Birds > Eagles\", \"Sports > Team Sports > Football\", \"Photography > Portrait Photography > Studio\""
		basePrompt = basePrompt .. hierarchicalAddendum
	end

	return basePrompt
end

-- Append EXIF/GPS metadata context to a prompt string.
-- Returns the prompt unchanged if metadata is disabled or unavailable.
function AICommon.appendMetadataToPrompt( prompt, photoObject )
	local prefs = LrPrefs.prefsForPlugin()
	if not (prefs.includeGpsExifData and photoObject) then
		return prompt
	end

	local metadata = AICommon.extractMetadata( photoObject )
	if not metadata then
		return prompt
	end

	logger:infof( "AICommon: Including EXIF/GPS metadata in analysis" )

	local parts = { prompt, "\n\nAdditional context from photo metadata:\n" }

	if metadata.gps then
		table.insert( parts, "GPS Location: " .. metadata.gps .. "\n" )
	end

	if metadata.camera then
		local cameraStr = string.format( "Camera: %s %s", metadata.camera.make or "", metadata.camera.model or "" )
		if metadata.camera.lens then
			cameraStr = cameraStr .. string.format( " with %s", metadata.camera.lens )
		end
		table.insert( parts, cameraStr .. "\n" )
	end

	if metadata.settings then
		local settings = {}
		if metadata.settings.focalLength then table.insert( settings, metadata.settings.focalLength ) end
		if metadata.settings.aperture then table.insert( settings, metadata.settings.aperture ) end
		if metadata.settings.shutterSpeed then table.insert( settings, metadata.settings.shutterSpeed ) end
		if metadata.settings.iso then table.insert( settings, "ISO " .. metadata.settings.iso ) end
		if metadata.settings.flash then table.insert( settings, "Flash: " .. metadata.settings.flash ) end
		if #settings > 0 then
			table.insert( parts, "Camera settings: " .. table.concat( settings, ", " ) .. "\n" )
		end
	end

	if metadata.datetime then
		table.insert( parts, "Captured: " .. metadata.datetime .. "\n" )
	end

	if metadata.image then
		if metadata.image.dimensions then
			table.insert( parts, "Image size: " .. metadata.image.dimensions .. "\n" )
		end
		if metadata.image.croppedDimensions then
			table.insert( parts, "Cropped size: " .. metadata.image.croppedDimensions .. "\n" )
		end
	end

	if metadata.copyright then
		table.insert( parts, "Copyright: " .. metadata.copyright .. "\n" )
	end

	if metadata.location then
		local locationParts = {}
		if metadata.location.city then table.insert( locationParts, metadata.location.city ) end
		if metadata.location.stateProvince then table.insert( locationParts, metadata.location.stateProvince ) end
		if metadata.location.country then table.insert( locationParts, metadata.location.country ) end
		if metadata.location.location then table.insert( locationParts, metadata.location.location ) end
		if #locationParts > 0 then
			table.insert( parts, "Location metadata: " .. table.concat( locationParts, ", " ) .. "\n" )
		end
	end

	if metadata.keywords then
		table.insert( parts, "Existing keywords already assigned to this photo: " .. table.concat( metadata.keywords, ", " ) .. "\n" )
	end

	local closingText = "\nPlease consider this technical and location information in your analysis"
	if metadata.gps or metadata.location then
		closingText = closingText .. ". IMPORTANT: GPS coordinates and location metadata provided above are authoritative — use them to identify the precise location name rather than guessing from visual content alone"
	end
	if metadata.keywords then
		closingText = closingText .. ". The existing keywords provide context about the photo subject (e.g., people names, project identifiers, events). Please reference this context in your caption and description where relevant, and suggest additional complementary keywords"
	elseif not (metadata.gps or metadata.location) then
		closingText = closingText .. " and include relevant location details in your response"
	end
	closingText = closingText .. "."
	table.insert( parts, closingText )

	return table.concat( parts )
end

--------------------------------------------------------------------------------
-- Response parsing

-- Parse keywords data (string, array, or object) into array of {description, selected} objects
function AICommon.parseKeywordsData( keywordsData )
	local keywords = {}

	if type(keywordsData) == "table" then
		local arrayLength = #keywordsData
		if arrayLength > 0 then
			for _, keyword in ipairs(keywordsData) do
				if type(keyword) == "string" and keyword ~= "" then
					local trimmed = string.match(keyword, "^%s*(.-)%s*$")
					if trimmed ~= "" then
						table.insert(keywords, { description = trimmed, selected = true })
					end
				end
			end
		else
			for keyword, _ in pairs(keywordsData) do
				if type(keyword) == "string" and keyword ~= "" then
					local trimmed = string.match(keyword, "^%s*(.-)%s*$")
					if trimmed ~= "" then
						table.insert(keywords, { description = trimmed, selected = true })
					end
				end
			end
		end
	elseif type(keywordsData) == "string" and keywordsData ~= "" then
		for keyword in string.gmatch(keywordsData, "([^,]+)") do
			local trimmed = string.match(keyword, "^%s*(.-)%s*$")
			if trimmed ~= "" then
				table.insert(keywords, { description = trimmed, selected = true })
			end
		end
	end

	return keywords
end

-- Build a standard analysis result table from a parsed JSON object
function AICommon.buildAnalysisResult( analysisResult )
	return {
		title = AICommon.fieldToString(analysisResult.title),
		caption = AICommon.fieldToString(analysisResult.caption),
		headline = AICommon.fieldToString(analysisResult.headline) ~= "" and AICommon.fieldToString(analysisResult.headline) or AICommon.fieldToString(analysisResult.description),
		instructions = AICommon.fieldToString(analysisResult.instructions),
		copyright = AICommon.fieldToString(analysisResult.copyright),
		location = AICommon.fieldToString(analysisResult.location),
		keywords = AICommon.parseKeywordsData(analysisResult.keywords or "")
	}
end

-- Return an empty analysis result set
function AICommon.emptyResults()
	return {
		title = "",
		caption = "",
		headline = "",
		instructions = "",
		copyright = "",
		location = "",
		keywords = {}
	}
end

--------------------------------------------------------------------------------
-- Batch processing

-- Generic batch processing with rate limiting.
-- analyzeFunc(fileName, jpegData, photo) -> result table
function AICommon.analyzeBatch( analyzeFunc, photos, progressCallback )
	local prefs = LrPrefs.prefsForPlugin()
	local batchSize = prefs.batchSize or 5
	local delay = prefs.delayBetweenRequests or 1000
	local results = {}

	for i = 1, #photos, batchSize do
		local batchEnd = math.min(i + batchSize - 1, #photos)

		for j = i, batchEnd do
			local photoData = photos[j]
			local result = analyzeFunc(photoData.fileName, photoData.jpegData, photoData.photo)
			table.insert(results, result)

			if progressCallback then
				progressCallback(j, #photos)
			end

			-- Add delay between requests to respect rate limits
			if j < batchEnd or batchEnd < #photos then
				LrTasks.sleep(delay / 1000)
			end
		end
	end

	return results
end

--------------------------------------------------------------------------------
-- File utilities

-- Load prompt from text file
function AICommon.loadPromptFromFile( filePath )
	if not filePath or filePath == "" then
		return nil, "No file path provided"
	end

	local success, file = pcall(io.open, filePath, "r")
	if not success or not file then
		return nil, "Could not open file: " .. tostring(file or filePath)
	end

	local readSuccess, content = pcall(function() return file:read("*all") end)
	file:close()

	if not readSuccess then
		return nil, "Could not read content from file: " .. tostring(content)
	end

	if not content or content == "" then
		return nil, "File is empty or could not read content"
	end

	content = LrStringUtils.trimWhitespace(content)

	return content, nil
end

--------------------------------------------------------------------------------
-- Prompt presets (delegated to PromptPresets module)

function AICommon.getPromptPresets()
	return PromptPresets.getPresets()
end

function AICommon.getPresetNames()
	return PromptPresets.getPresetNames()
end

function AICommon.getPreset( name )
	return PromptPresets.getPreset( name )
end

--------------------------------------------------------------------------------

return AICommon
