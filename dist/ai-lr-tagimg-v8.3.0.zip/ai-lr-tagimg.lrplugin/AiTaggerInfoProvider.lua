--[[----------------------------------------------------------------------------

 AI Image Tagger
 Copyright 2024 Anand Kumar Sankaran
 Updated for Lightroom Classic 2024 and Gemini AI

--------------------------------------------------------------------------------

AiTaggerInfoProvider.lua

------------------------------------------------------------------------------]]

local LrApplication = import "LrApplication"
local LrPrefs = import "LrPrefs"
local LrTasks = import "LrTasks"
local LrHttp = import "LrHttp"
local LrShell = import "LrShell"
local LrFileUtils = import "LrFileUtils"
local LrStringUtils = import "LrStringUtils"
local LrPathUtils = import "LrPathUtils"
local LrDialogs = import "LrDialogs"
local LrBinding = import "LrBinding"
local LrColor = import "LrColor"
local LrView = import "LrView"
local bind = LrView.bind
local share = LrView.share

--------------------------------------------------------------------------------

local inspect = require "inspect"
require "Logger"
require "AIProviderFactory"

--------------------------------------------------------------------------------

local prefs = LrPrefs.prefsForPlugin()

-- shared properties for aligning prompts
local propGeneralOptionsPromptWidth = "generalOptionsPromptWidth"
local propKeywordOptionsPromptWidth = "keywordOptionsPromptWidth"
local propCredentialsPromptWidth = "credentialsPromptWidth"

-- properties for option controls
local propGeneralMaxTasks = "generalMaxTasks"
local propThumbnailResolution = "thumbnailResolution"

local propDecorateKeyword = "decorateKeyword"
local propDecorateKeywordValue = "decorateKeywordValue"
local propUseHierarchicalKeywords = "useHierarchicalKeywords"
local propKeywordHierarchySeparator = "keywordHierarchySeparator"
local propCreateFullHierarchy = "createFullHierarchy"
local propMaxHierarchyDepth = "maxHierarchyDepth"
local propMaxKeywords = "maxKeywords"
local propMaxAIKeywords = "maxAIKeywords"
local propGeminiModel = "geminiModel"

local propSaveTitleToIptc = "saveTitleToIptc"
local propSaveCaptionToIptc = "saveCaptionToIptc"
local propSaveHeadlineToIptc = "saveHeadlineToIptc"
local propSaveInstructionsToIptc = "saveInstructionsToIptc"
local propAddAiTaggerMarker = "addAiTaggerMarker"
local propSaveCopyrightToIptc = "saveCopyrightToIptc"
local propSaveLocationToIptc = "saveLocationToIptc"

local propUseCustomPrompt = "useCustomPrompt"
local propCustomPrompt = "customPrompt"
local propBatchSize = "batchSize"
local propDelayBetweenRequests = "delayBetweenRequests"
local propIncludeGpsExifData = "includeGpsExifData"
local propResponseLanguage = "responseLanguage"

local propApiKey = "apiKey"
local propOpenAIApiKey = "openaiApiKey"
local propOpenAIModel = "openaiModel"
local propVersions = "versions"

-- AI Provider properties
local propAiProvider = "aiProvider"
local propOllamaBaseUrl = "ollamaBaseUrl"
local propOllamaModel = "ollamaModel"
local propOllamaTimeout = "ollamaTimeout"
local propOllamaModelItems = "ollamaModelItems"
local propOllamaCustomModel = "ollamaCustomModel"
local propOllamaUseCustomModel = "ollamaUseCustomModel"

local ollamaDefaultModelItems = {
	{ title = "Qwen3-VL 8B (Recommended)", value = "qwen3-vl:8b" },
	{ title = "Qwen3-VL 2B (Lightweight)", value = "qwen3-vl:2b" },
	{ title = "Qwen3-VL 4B (Fast)", value = "qwen3-vl:4b" },
	{ title = "Qwen3-VL 30B (High Quality)", value = "qwen3-vl:30b" },
	{ title = "Gemma 3 4B (Multimodal)", value = "gemma3:4b" },
	{ title = "Gemma 3 12B (Multimodal)", value = "gemma3:12b" },
	{ title = "Gemma 3 27B (Multimodal)", value = "gemma3:27b" },
	{ title = "Llama 3.2 Vision 11B", value = "llama3.2-vision:11b" },
	{ title = "Llama 3.2 Vision 90B", value = "llama3.2-vision:90b" },
	{ title = "Qwen 2.5-VL 7B", value = "qwen2.5vl:7b" },
	{ title = "Qwen 2.5-VL 32B", value = "qwen2.5vl:32b" },
	{ title = "Qwen 2.5-VL 72B", value = "qwen2.5vl:72b" },
	{ title = "MiniCPM-V (Efficient)", value = "minicpm-v:latest" },
	{ title = "LLaVA 1.5 (Legacy)", value = "llava:latest" },
	{ title = "LLaVA-Llama3 (Legacy)", value = "llava-llama3:latest" },
	{ title = "Moondream (Lightweight)", value = "moondream:latest" },
}

-- auto collections properties
local propCreateAutoCollections = "createAutoCollections"
local propCollectionScheme = "collectionScheme"

-- canned strings
local loadingText = LOC( "$$$/AiTagger/Options/Loading=loading..." )

local titleKeywordAsIs   = LOC( "$$$/AiTagger/Options/DecorateKeywords/Title/None=as-is" )
local titleKeywordPrefix = LOC( "$$$/AiTagger/Options/DecorateKeywords/Title/Prefix=with Prefix" )
local titleKeywordSuffix = LOC( "$$$/AiTagger/Options/DecorateKeywords/Title/Suffix=with Suffix" )
local titleKeywordParent = LOC( "$$$/AiTagger/Options/DecorateKeywords/Title/Parent=under Parent" )

local placeholderKeywordPrefix = LOC( "$$$/AiTagger/Options/DecorateKeywords/PlaceHolder/Prefix=<prefix>" )
local placeholderKeywordSuffix = LOC( "$$$/AiTagger/Options/DecorateKeywords/PlaceHolder/Suffix=<suffix>" )
local placeholderKeywordParent = LOC( "$$$/AiTagger/Options/DecorateKeywords/PlaceHolder/Parent=<parent>" )

--------------------------------------------------------------------------------


local function loadApiKey( propertyTable, provider )
	provider = provider or propertyTable[ propAiProvider ]
	local api = AIProviderFactory.getAPIForProvider( provider )
	local apiKey = ""
	if api and api.getApiKey then
		apiKey = api.getApiKey() or ""
	end

	if provider == "openai" then
		propertyTable[ propOpenAIApiKey ] = apiKey
	else
		propertyTable[ propApiKey ] = apiKey
	end
end

local function storeApiKey( propertyTable, provider )
	provider = provider or propertyTable[ propAiProvider ]
	local api = AIProviderFactory.getAPIForProvider( provider )
	if not api then
		return
	end

	local rawKey
	if provider == "openai" then
		rawKey = propertyTable[ propOpenAIApiKey ]
	else
		rawKey = propertyTable[ propApiKey ]
	end

	local apiKey = LrStringUtils.trimWhitespace( rawKey or "" )

	if apiKey ~= "" then
		if api.storeApiKey then
			api.storeApiKey( apiKey )
		end
	else
		if api.clearApiKey then
			api.clearApiKey()
		end
	end
end

local function clearApiKey( propertyTable, provider )
	provider = provider or propertyTable[ propAiProvider ]
	local api = AIProviderFactory.getAPIForProvider( provider )
	if api and api.clearApiKey then
		api.clearApiKey()
	end

	if provider == "openai" then
		propertyTable[ propOpenAIApiKey ] = ""
	else
		propertyTable[ propApiKey ] = ""
	end
end

local function startDialog( propertyTable )
	-- Load AI provider settings
	propertyTable[ propAiProvider ] = AIProviderFactory.getCurrentProvider()
	
	-- Preload stored API keys for all providers so Cancel won't wipe them
	loadApiKey( propertyTable, "gemini" )
	loadApiKey( propertyTable, "openai" )
	
	-- Load Ollama settings
	local ollamaApi = AIProviderFactory.getAPIForProvider( "ollama" )
	if ollamaApi and ollamaApi.getBaseUrl then
		propertyTable[ propOllamaBaseUrl ] = ollamaApi.getBaseUrl()
	else
		propertyTable[ propOllamaBaseUrl ] = "http://localhost:11434"
	end
	
	if ollamaApi and ollamaApi.getModel then
		propertyTable[ propOllamaModel ] = ollamaApi.getModel()
	else
		propertyTable[ propOllamaModel ] = ""
	end
	
	if ollamaApi and ollamaApi.getTimeout then
		propertyTable[ propOllamaTimeout ] = ollamaApi.getTimeout() / 1000 -- Convert to seconds for UI
	else
		propertyTable[ propOllamaTimeout ] = 300
	end

	-- Initialize Ollama model list with defaults; async fetch will replace with installed models
	propertyTable[ propOllamaModelItems ] = ollamaDefaultModelItems
	-- Check if the saved model is in the default list; if not, treat it as a custom model
	local savedOllamaModel = propertyTable[ propOllamaModel ] or ""
	local savedModelInDefaultList = false
	for _, item in ipairs( ollamaDefaultModelItems ) do
		if item.value == savedOllamaModel then
			savedModelInDefaultList = true
			break
		end
	end
	if savedModelInDefaultList then
		propertyTable[ propOllamaUseCustomModel ] = false
		propertyTable[ propOllamaCustomModel ] = ""
	else
		propertyTable[ propOllamaUseCustomModel ] = true
		propertyTable[ propOllamaCustomModel ] = savedOllamaModel
	end

	-- Async fetch of installed Ollama models
	LrTasks.startAsyncTask( function()
		if ollamaApi and ollamaApi.fetchInstalledModels then
			local installedItems = ollamaApi.fetchInstalledModels()
			if installedItems and #installedItems > 0 then
				propertyTable[ propOllamaModelItems ] = installedItems
				-- If current model isn't in the fetched list, keep value so user sees it selected
				logger:infof( "AiTaggerInfoProvider: Populated Ollama model list with %d installed models", #installedItems )
			end
		end
	end )
	
	propertyTable[ propVersions ] = {
		gemini = { version = loadingText },
		ollama = { version = loadingText },
		openai = { version = loadingText },
	}
	LrTasks.startAsyncTask(
		function()
			local combined = {}
			for _, providerId in ipairs({ "gemini", "ollama", "openai" }) do
				local versionInfo = AIProviderFactory.getVersionsForProvider( providerId ) or {}
				for key, value in pairs( versionInfo ) do
					combined[key] = value
				end
			end
			propertyTable[ propVersions ] = combined
		end
	)
	
	-- Add observer for AI provider changes
	propertyTable:addObserver( propAiProvider, function( properties, key, newValue )
		if newValue then
			loadApiKey( propertyTable, newValue )
		end
	end )

	propertyTable[ propGeneralMaxTasks ] = prefs.maxTasks
	propertyTable[ propThumbnailResolution ] = prefs.thumbnailResolution

	propertyTable[ propDecorateKeyword ] = prefs.decorateKeyword
	propertyTable[ propDecorateKeywordValue ] = prefs.decorateKeywordValue
	propertyTable[ propUseHierarchicalKeywords ] = prefs.useHierarchicalKeywords
	propertyTable[ propKeywordHierarchySeparator ] = prefs.keywordHierarchySeparator
	propertyTable[ propCreateFullHierarchy ] = prefs.createFullHierarchy
	propertyTable[ propMaxHierarchyDepth ] = prefs.maxHierarchyDepth
	propertyTable[ propMaxKeywords ] = prefs.maxKeywords
	propertyTable[ propMaxAIKeywords ] = prefs.maxAIKeywords
	propertyTable[ propGeminiModel ] = prefs.geminiModel
	propertyTable[ propOpenAIModel ] = prefs.openaiModel or "gpt-4o"

	propertyTable[ propSaveTitleToIptc ] = prefs.saveTitleToIptc
	propertyTable[ propSaveCaptionToIptc ] = prefs.saveCaptionToIptc
	propertyTable[ propSaveHeadlineToIptc ] = prefs.saveHeadlineToIptc
	propertyTable[ propSaveInstructionsToIptc ] = prefs.saveInstructionsToIptc
	propertyTable[ propAddAiTaggerMarker ] = prefs.addAiTaggerMarker == true
	propertyTable[ propSaveCopyrightToIptc ] = prefs.saveCopyrightToIptc
	propertyTable[ propSaveLocationToIptc ] = prefs.saveLocationToIptc

	propertyTable[ propUseCustomPrompt ] = prefs.useCustomPrompt
	propertyTable[ propCustomPrompt ] = prefs.customPrompt or ""
	propertyTable[ "selectedPreset" ] = ""
	propertyTable[ propBatchSize ] = prefs.batchSize
	propertyTable[ propDelayBetweenRequests ] = prefs.delayBetweenRequests
	propertyTable[ propIncludeGpsExifData ] = prefs.includeGpsExifData
	propertyTable[ propResponseLanguage ] = prefs.responseLanguage or "English"
	
	-- auto collections properties
	propertyTable[ propCreateAutoCollections ] = prefs.createAutoCollections or false
	propertyTable[ propCollectionScheme ] = prefs.collectionScheme or "Content-Based"

	-- Add observer for preset selection
	propertyTable:addObserver( "selectedPreset", function( properties, key, newValue )
		if newValue and newValue ~= "" then
			local preset = AIProviderFactory.getPreset(newValue)
			if preset then
				-- Direct property assignment
				propertyTable[propCustomPrompt] = preset.prompt
				-- Force UI refresh
				local currentValue = propertyTable[propUseCustomPrompt]
				propertyTable[propUseCustomPrompt] = not currentValue
				propertyTable[propUseCustomPrompt] = currentValue
				-- Reset dropdown selection
				propertyTable["selectedPreset"] = ""
			else
				logger:errorf("Failed to get preset: %s", newValue)
			end
		end
	end )

	loadApiKey( propertyTable, propertyTable[ propAiProvider ] )
end

local function endDialog( propertyTable )
	prefs.maxTasks = propertyTable[ propGeneralMaxTasks ]
	prefs.thumbnailResolution = propertyTable[ propThumbnailResolution ]
	prefs.thumbnailWidth = prefs.thumbnailResolution
	prefs.thumbnailHeight = prefs.thumbnailResolution

	prefs.decorateKeyword = propertyTable[ propDecorateKeyword ]
	prefs.decorateKeywordValue = LrStringUtils.trimWhitespace( propertyTable[ propDecorateKeywordValue ] or "" )
	prefs.useHierarchicalKeywords = propertyTable[ propUseHierarchicalKeywords ]
	prefs.keywordHierarchySeparator = propertyTable[ propKeywordHierarchySeparator ] or " > "
	prefs.createFullHierarchy = propertyTable[ propCreateFullHierarchy ]
	prefs.maxHierarchyDepth = propertyTable[ propMaxHierarchyDepth ]
	prefs.maxKeywords = propertyTable[ propMaxKeywords ]
	prefs.maxAIKeywords = propertyTable[ propMaxAIKeywords ]
	prefs.geminiModel = propertyTable[ propGeminiModel ]
	prefs.openaiModel = propertyTable[ propOpenAIModel ]

	prefs.saveTitleToIptc = propertyTable[ propSaveTitleToIptc ]
	prefs.saveCaptionToIptc = propertyTable[ propSaveCaptionToIptc ]
	prefs.saveHeadlineToIptc = propertyTable[ propSaveHeadlineToIptc ]
	prefs.saveInstructionsToIptc = propertyTable[ propSaveInstructionsToIptc ]
	prefs.addAiTaggerMarker = propertyTable[ propAddAiTaggerMarker ]
	prefs.saveCopyrightToIptc = propertyTable[ propSaveCopyrightToIptc ]
	prefs.saveLocationToIptc = propertyTable[ propSaveLocationToIptc ]

	prefs.useCustomPrompt = propertyTable[ propUseCustomPrompt ]
	prefs.customPrompt = LrStringUtils.trimWhitespace( propertyTable[ propCustomPrompt ] or "" )
	prefs.batchSize = propertyTable[ propBatchSize ]
	prefs.delayBetweenRequests = propertyTable[ propDelayBetweenRequests ]
	prefs.includeGpsExifData = propertyTable[ propIncludeGpsExifData ]
	prefs.responseLanguage = propertyTable[ propResponseLanguage ]
	
	-- auto collections preferences
	prefs.createAutoCollections = propertyTable[ propCreateAutoCollections ]
	prefs.collectionScheme = propertyTable[ propCollectionScheme ]
	
	-- Save Ollama settings unconditionally (before switching provider, so they
	-- are not lost if user edited Ollama settings then switched to a different provider)
	OllamaAPI.setBaseUrl( LrStringUtils.trimWhitespace( propertyTable[ propOllamaBaseUrl ] or "http://localhost:11434" ) )
	local ollamaModelToSave
	if propertyTable[ propOllamaUseCustomModel ] then
		ollamaModelToSave = LrStringUtils.trimWhitespace( propertyTable[ propOllamaCustomModel ] or "" )
		if ollamaModelToSave == "" then
			ollamaModelToSave = LrStringUtils.trimWhitespace( propertyTable[ propOllamaModel ] or "" )
		end
	else
		ollamaModelToSave = LrStringUtils.trimWhitespace( propertyTable[ propOllamaModel ] or "" )
	end
	OllamaAPI.setModel( ollamaModelToSave )
	OllamaAPI.setTimeout( ( propertyTable[ propOllamaTimeout ] or 300 ) * 1000 )

	-- Save provider-specific API keys (handles blank values by clearing storage)
	storeApiKey( propertyTable, "gemini" )
	storeApiKey( propertyTable, "openai" )

	-- Save AI provider setting after persisting credentials
	AIProviderFactory.setCurrentProvider( propertyTable[ propAiProvider ] )
end

local function sectionsForTopOfDialog( f, propertyTable )

	return {
		-- AI Provider selection
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Provider/Title=AI Provider" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Provider/Select=AI Provider:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propAiProvider },
					items = {
						{ title = "Google Gemini", value = "gemini" },
						{ title = "OpenAI GPT", value = "openai" },
						{ title = "Ollama (Local)", value = "ollama" },
					},
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Provider/Help=Choose between Google Gemini, OpenAI GPT cloud services, or local Ollama server. Cloud services require API keys, Ollama requires local installation." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 2,
				},
			},
		},
		-- general options
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/General/Title=General Options" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/General/MaxTasks=Max Parallel Requests:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					placeholder_string = LOC( "$$$/AiTagger/Options/General/MaxTasksPlaceholder=<max requests>" ),
					value = bind { key = propGeneralMaxTasks },
					immediate = true,
					min = AiTaggerConstants.tasksMin,
					max = AiTaggerConstants.tasksMax,
					increment = AiTaggerConstants.tasksStep,
					precision = 0,
					width_in_digits = 4,
				},
				f:static_text {
					title = string.format( "%d", AiTaggerConstants.tasksMin ),
					alignment = "right",
				},
				f:slider {
					fill_horizontal = 1,
					value = bind { key = propGeneralMaxTasks },
					min = AiTaggerConstants.tasksMin,
					max = AiTaggerConstants.tasksMax,
					integral = AiTaggerConstants.tasksStep,
				},
				f:static_text {
					title = string.format( "%d", AiTaggerConstants.tasksMax ),
					alignment = "left",
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/General/ThumbnailRes=Thumbnail Resolution:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					placeholder_string = LOC( "$$$/AiTagger/Options/General/ThumbnailResPlaceholder=<pixels>" ),
					value = bind { key = propThumbnailResolution },
					immediate = true,
					min = AiTaggerConstants.thumbnailResMin,
					max = AiTaggerConstants.thumbnailResMax,
					increment = AiTaggerConstants.thumbnailResStep,
					precision = 0,
					width_in_digits = 4,
				},
				f:static_text {
					title = string.format( "%d", AiTaggerConstants.thumbnailResMin ),
					alignment = "right",
				},
				f:slider {
					fill_horizontal = 1,
					value = bind { key = propThumbnailResolution },
					min = AiTaggerConstants.thumbnailResMin,
					max = AiTaggerConstants.thumbnailResMax,
					integral = AiTaggerConstants.thumbnailResStep,
				},
				f:static_text {
					title = string.format( "%d", AiTaggerConstants.thumbnailResMax ),
					alignment = "left",
				},
			},
		},
		-- Ollama Configuration
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Ollama/Title=Ollama Configuration" ),
			spacing = f:control_spacing(),
			visible = LrBinding.keyEquals( propAiProvider, "ollama" ),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Ollama/BaseUrl=Server URL:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propOllamaBaseUrl },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Ollama/Model=Model:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propOllamaModel },
					items = bind { key = propOllamaModelItems },
					enabled = LrBinding.negativeOfKey( propOllamaUseCustomModel ),
					width_in_chars = 40,
				},
				f:push_button {
					title = LOC( "$$$/AiTagger/Options/Ollama/RefreshModels=Refresh" ),
					tooltip = LOC( "$$$/AiTagger/Options/Ollama/RefreshModelsTooltip=Query your Ollama server for installed models" ),
					enabled = LrBinding.negativeOfKey( propOllamaUseCustomModel ),
					action = function()
						LrTasks.startAsyncTask( function()
							local ollamaApi = AIProviderFactory.getAPIForProvider( "ollama" )
							if ollamaApi and ollamaApi.fetchInstalledModels then
								local installedItems = ollamaApi.fetchInstalledModels()
								if installedItems and #installedItems > 0 then
									propertyTable[ propOllamaModelItems ] = installedItems
									logger:infof( "AiTaggerInfoProvider: Refreshed Ollama model list with %d models", #installedItems )
								else
									LrDialogs.message(
										LOC( "$$$/AiTagger/Options/Ollama/RefreshFailed=Refresh Failed" ),
										LOC( "$$$/AiTagger/Options/Ollama/RefreshFailedMsg=Could not connect to Ollama server or no models found. Make sure Ollama is running." ),
										"warning"
									)
								end
							end
						end )
					end,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = " ",
					width = share( propGeneralOptionsPromptWidth ),
				},
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/Ollama/UseCustomModel=Enter model name manually" ),
					value = bind { key = propOllamaUseCustomModel },
				},
			},
			f:row {
				fill_horizontal = 1,
				visible = bind { key = propOllamaUseCustomModel },
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Ollama/CustomModel=Custom Model:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propOllamaCustomModel },
					fill_horizontal = 1,
					placeholder_string = "e.g. gemma4:e4b",
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Ollama/Timeout=Timeout (seconds):" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propOllamaTimeout },
					min = 30,
					max = 600,
					increment = 30,
					precision = 0,
					width_in_digits = 4,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Ollama/Help=Models are fetched automatically from your Ollama server. Use 'Refresh' to update the list, or check 'Enter model name manually' to type any model name. Run 'ollama pull <model>' to install new models." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 3,
				},
			},
		},
		-- language options
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Language/Title=AI Response Language" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Language/Prompt=AI Response Language:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propResponseLanguage },
					items = {
						{ title = LOC( "$$$/AiTagger/Language/English=English" ), value = "English" },
						{ title = LOC( "$$$/AiTagger/Language/Spanish=Spanish" ), value = "Spanish" },
						{ title = LOC( "$$$/AiTagger/Language/French=French" ), value = "French" },
						{ title = LOC( "$$$/AiTagger/Language/German=German" ), value = "German" },
						{ title = LOC( "$$$/AiTagger/Language/Italian=Italian" ), value = "Italian" },
						{ title = LOC( "$$$/AiTagger/Language/Portuguese=Portuguese" ), value = "Portuguese" },
						{ title = LOC( "$$$/AiTagger/Language/Russian=Russian" ), value = "Russian" },
						{ title = LOC( "$$$/AiTagger/Language/Japanese=Japanese" ), value = "Japanese" },
						{ title = LOC( "$$$/AiTagger/Language/Korean=Korean" ), value = "Korean" },
						{ title = LOC( "$$$/AiTagger/Language/ChineseSimplified=Chinese (Simplified)" ), value = "Chinese" },
						{ title = LOC( "$$$/AiTagger/Language/Dutch=Dutch" ), value = "Dutch" },
						{ title = LOC( "$$$/AiTagger/Language/Polish=Polish" ), value = "Polish" },
						{ title = LOC( "$$$/AiTagger/Language/Turkish=Turkish" ), value = "Turkish" },
						{ title = LOC( "$$$/AiTagger/Language/Arabic=Arabic" ), value = "Arabic" },
						{ title = LOC( "$$$/AiTagger/Language/Hindi=Hindi" ), value = "Hindi" },
						{ title = LOC( "$$$/AiTagger/Language/Tamil=Tamil" ), value = "Tamil" },
						{ title = LOC( "$$$/AiTagger/Language/Czech=Czech" ), value = "Czech" },
					},
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Language/Help=Select the language for AI-generated titles, captions, descriptions, and keywords. This setting applies to all AI provider responses." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 2,
				},
			},
		},
		-- keyword options
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Keywords/Title=Keyword Options" ),
			spacing = f:control_spacing(),

			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/Prompt=Create Keywords:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propDecorateKeyword },
					items = {
						{ title = titleKeywordAsIs,   value = AiTaggerConstants.decorateKeywordAsIs   },
						{ title = titleKeywordPrefix, value = AiTaggerConstants.decorateKeywordPrefix },
						{ title = titleKeywordSuffix, value = AiTaggerConstants.decorateKeywordSuffix },
						{ title = titleKeywordParent, value = AiTaggerConstants.decorateKeywordParent },
					},
				},
				f:row {
					place = "overlapping",
					fill_horizontal = 0.5,
					f:edit_field {
						visible = LrBinding.keyEquals( propDecorateKeyword, AiTaggerConstants.decorateKeywordPrefix ),
						placeholder_string = placeholderKeywordPrefix,
						value = bind { key = propDecorateKeywordValue },
						immediate = true,
						width_in_chars = 10,
					},
					f:edit_field {
						visible = LrBinding.keyEquals( propDecorateKeyword, AiTaggerConstants.decorateKeywordSuffix ),
						placeholder_string = placeholderKeywordSuffix,
						value = bind { key = propDecorateKeywordValue },
						immediate = true,
						width_in_chars = 10,
					},
					f:edit_field {
						visible = LrBinding.keyEquals( propDecorateKeyword, AiTaggerConstants.decorateKeywordParent ),
						placeholder_string = placeholderKeywordParent,
						value = bind { key = propDecorateKeywordValue },
						immediate = true,
						width_in_chars = 10,
					},
				},
			},
			
			-- Hierarchical keyword options
			f:separator { fill_horizontal = 1, height = 1 },
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/Keywords/Hierarchical=Use hierarchical keywords (e.g., Nature > Wildlife > Birds)" ),
					value = bind { key = propUseHierarchicalKeywords },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/Separator=Hierarchy Separator:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propKeywordHierarchySeparator },
					immediate = true,
					enabled = bind { key = propUseHierarchicalKeywords },
					width_in_chars = 8,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/SeparatorHelp=(default: ' > ')" ),
					enabled = bind { key = propUseHierarchicalKeywords },
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxDepth=Max Hierarchy Depth:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propMaxHierarchyDepth },
					immediate = true,
					enabled = bind { key = propUseHierarchicalKeywords },
					min = 2,
					max = 6,
					increment = 1,
					precision = 0,
					width_in_digits = 2,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxDepthHelp=(2-6 levels, prevents excessive nesting)" ),
					enabled = bind { key = propUseHierarchicalKeywords },
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/Keywords/FullHierarchy=Create full keyword hierarchy (all parent keywords)" ),
					value = bind { key = propCreateFullHierarchy },
					enabled = bind { key = propUseHierarchicalKeywords },
					fill_horizontal = 1,
				},
			},
			f:separator { fill_horizontal = 1, height = 1 },

			-- Keyword count configuration
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxAIKeywords=AI Keywords to Generate:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propMaxAIKeywords },
					immediate = true,
					min = 5,
					max = 75,
					increment = 1,
					precision = 0,
					width_in_digits = 3,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxAIKeywordsHelp=(5-75 keywords requested from AI)" ),
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxKeywords=UI Keywords to Display:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propMaxKeywords },
					immediate = true,
					min = 5,
					max = 75,
					increment = 1,
					precision = 0,
					width_in_digits = 3,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Keywords/MaxKeywordsHelp=(5-75 keyword slots in results dialog)" ),
				},
			},
			f:separator { fill_horizontal = 1, height = 1 },
			
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveTitle=Save title to IPTC metadata" ),
					value = bind { key = propSaveTitleToIptc },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveCaption=Save caption to IPTC metadata" ),
					value = bind { key = propSaveCaptionToIptc },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveHeadline=Save headline to IPTC metadata" ),
					value = bind { key = propSaveHeadlineToIptc },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveInstructions=Save instructions to IPTC metadata" ),
					value = bind { key = propSaveInstructionsToIptc },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/AddAiTaggerMarker=Add AiTagger marker to Instructions field (enables filtering processed photos in Library)" ),
					value = bind { key = propAddAiTaggerMarker },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveCopyright=Save copyright to IPTC metadata" ),
					value = bind { key = propSaveCopyrightToIptc },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/IPTC/SaveLocation=Save location to IPTC metadata" ),
					value = bind { key = propSaveLocationToIptc },
					fill_horizontal = 1,
				},
			},
		},

		-- AI prompt customization
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/AI/Title=AI Prompt Customization" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/AI/UseCustomPrompt=Use custom prompt" ),
					value = bind { key = propUseCustomPrompt },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/AI/PromptPresets=Preset Prompts:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					enabled = bind { key = propUseCustomPrompt },
					items = (function()
						local items = {{ title = LOC( "$$$/AiTagger/Preset/SelectPreset=Select a preset..." ), value = "" }}
						local presets = AIProviderFactory.getPromptPresets()
						for _, preset in ipairs(presets) do
							table.insert(items, { title = preset.name .. " - " .. preset.description, value = preset.name })
						end
						return items
					end)(),
					value = bind { key = "selectedPreset" },
				},
				f:spacer { width = 8 },
				f:push_button {
					title = LOC( "$$$/AiTagger/Options/AI/ViewExamples=View Prompt Examples..." ),
					action = function()
						LrHttp.openUrlInBrowser("https://github.com/obelix74/docs/blob/main/lr/PROMPTS.md")
					end,
				},
				f:push_button {
					enabled = bind { key = propUseCustomPrompt },
					title = LOC( "$$$/AiTagger/Options/AI/BrowseFile=Browse File..." ),
					action = function()
						local fileName = LrDialogs.runOpenPanel({
							title = LOC( "$$$/AiTagger/Prompt/SelectFile=Select Prompt File" ),
							prompt = LOC( "$$$/AiTagger/Prompt/ChooseFile=Choose a text file containing your custom prompt:" ),
							canChooseFiles = true,
							canChooseDirectories = false,
							allowsMultipleSelection = false,
							fileTypes = { "txt", "text" },
							initialDirectory = LrPathUtils.getStandardFilePath( "documents" ),
						})

						if fileName and fileName[1] then
							local content, error = AIProviderFactory.loadPromptFromFile(fileName[1])
							if content then
								-- Direct property assignment
								propertyTable[propCustomPrompt] = content
								-- Force UI refresh
								local currentValue = propertyTable[propUseCustomPrompt]
								propertyTable[propUseCustomPrompt] = not currentValue
								propertyTable[propUseCustomPrompt] = currentValue
							else
								logger:errorf("Failed to load file: %s", error or "unknown error")
								LrDialogs.message( LOC( "$$$/AiTagger/Prompt/ErrorLoadingFile=Error Loading File" ), error or LOC( "$$$/AiTagger/Prompt/CouldNotLoadFile=Could not load prompt from file." ), "error" )
							end
						end
					end,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/AI/CustomPrompt=Custom Prompt:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					enabled = bind { key = propUseCustomPrompt },
					placeholder_string = LOC( "$$$/AiTagger/Options/AI/CustomPromptPlaceholder=Enter your custom prompt here or select a preset above..." ),
					value = bind { key = propCustomPrompt },
					fill_horizontal = 1,
					height_in_lines = 8,
					scrollable = true,
					wrap = true,
				},
			},
		},

		-- batch processing options
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Batch/Title=Batch Processing" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Batch/BatchSize=Batch Size:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propBatchSize },
					immediate = true,
					min = 1,
					max = 10,
					increment = 1,
					precision = 0,
					width_in_digits = 2,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Batch/BatchSizeHelp=(1-10 photos per batch)" ),
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Batch/Delay=Delay Between Requests:" ),
					width = share( propKeywordOptionsPromptWidth ),
					alignment = "right",
				},
				f:edit_field {
					value = bind { key = propDelayBetweenRequests },
					immediate = true,
					min = 500,
					max = 5000,
					increment = 100,
					precision = 0,
					width_in_digits = 4,
				},
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Batch/DelayHelp=milliseconds (500-5000)" ),
				},
			},
		},

		-- Privacy options
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Privacy/Title=Privacy & Metadata" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/Privacy/IncludeGpsExif=Include GPS location and EXIF metadata in AI analysis" ),
					value = bind { key = propIncludeGpsExifData },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Privacy/IncludeGpsExifHelp=When enabled, camera settings, GPS coordinates, and technical metadata will be shared with the AI provider to enhance analysis accuracy.\nFor Ollama (local), data stays on your machine. For cloud providers, data is sent externally." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 3,
				},
			},
		},

		-- Gemini Model Selection
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/GeminiModel/Title=Gemini Model" ),
			visible = LrBinding.keyEquals( propAiProvider, "gemini" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/GeminiModel/Model=Model:" ),
					width = share( propCredentialsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propGeminiModel },
					items = {
						{ title = "Gemini 3.1 Pro (Preview - Latest)", value = "gemini-3.1-pro-preview" },
						{ title = "Gemini 2.5 Flash (Best Performance)", value = "gemini-2.5-flash" },
						{ title = "Gemini 2.5 Pro (High Quality)", value = "gemini-2.5-pro" },
						{ title = "Gemini 2.0 Flash (Fast)", value = "gemini-2.0-flash" },
					},
					width_in_chars = 42,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/GeminiModel/Help=3 Pro: Latest and most advanced model. 2.5 Flash: Best price-performance balance. 2.5 Pro: Highest quality and thinking mode. 2.0 Flash: Fast and efficient." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 2,
					wrap = true,
				},
			},
		},
		-- OpenAI Model Selection
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/OpenAIModel/Title=OpenAI Model" ),
			visible = LrBinding.keyEquals( propAiProvider, "openai" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/OpenAIModel/Model=Model:" ),
					width = share( propCredentialsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					value = bind { key = propOpenAIModel },
					items = {
						{ title = "GPT-4o (Latest & Recommended)", value = "gpt-4o" },
						{ title = "GPT-4o Mini (Fast & Affordable)", value = "gpt-4o-mini" },
						{ title = "GPT-4 Turbo (High Quality)", value = "gpt-4-turbo" },
						{ title = "GPT-4 Vision Preview", value = "gpt-4-vision-preview" },
					},
					width_in_chars = 35,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/OpenAIModel/Help=GPT-4o: Latest model with best performance. GPT-4o Mini: Fastest and most affordable. Turbo: High quality analysis." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 2,
					wrap = true,
				},
			},
		},

		-- Gemini API key
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/ApiKey/Title=Gemini API Key" ),
			visible = LrBinding.keyEquals( propAiProvider, "gemini" ),
			synopsis = bind {
				key = propApiKey,
				object = propertyTable,
				transform = function( value, fromTable )
					if value and value ~= "" then
						return LOC( "$$$/AiTagger/ApiKey/Configured=API key configured" )
					else
						return LOC( "$$$/AiTagger/ApiKey/NotConfigured=API key not configured" )
					end
				end,
			},
			spacing = f:control_spacing(),
			f:row {
				f:static_text {
					title = LOC( "$$$/AiTagger/ApiKey/Key=API Key:" ),
					width = share( propCredentialsPromptWidth ),
					alignment = "right",
				},
				f:password_field {
					placeholder_string = LOC( "$$$/AiTagger/ApiKey/KeyPlaceHolder=<API key>" ),
					value = bind { key = propApiKey },
					immediate = true,
					fill_horizontal = 1,
					height_in_lines = 1,
				},
			},
			f:row {
				f:push_button {
					title = LOC( "$$$/AiTagger/ApiKey/Setup=Get API Key..." ),
					place_horizontal = 1,
					action = function( btn )
						LrHttp.openUrlInBrowser( "https://ai.google.dev/gemini-api/docs/api-key" )
					end,
				},
				f:push_button {
					title = LOC( "$$$/AiTagger/ApiKey/Clear=Clear" ),
					place_horizontal = 1,
					action = function( btn )
						propertyTable[ propApiKey ] = ""
						clearApiKey( propertyTable, "gemini" )
					end,
				},
			},
		},
		-- OpenAI API key
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/ApiKey/OpenAI/Title=OpenAI API Key" ),
			visible = LrBinding.keyEquals( propAiProvider, "openai" ),
			synopsis = bind {
				key = propOpenAIApiKey,
				object = propertyTable,
				transform = function( value, fromTable )
					if value and value ~= "" then
						return LOC( "$$$/AiTagger/ApiKey/Configured=API key configured" )
					else
						return LOC( "$$$/AiTagger/ApiKey/NotConfigured=API key not configured" )
					end
				end,
			},
			spacing = f:control_spacing(),
			f:row {
				f:static_text {
					title = LOC( "$$$/AiTagger/ApiKey/Key=API Key:" ),
					width = share( propCredentialsPromptWidth ),
					alignment = "right",
				},
				f:password_field {
					placeholder_string = LOC( "$$$/AiTagger/ApiKey/OpenAI/KeyPlaceHolder=<OpenAI API key>" ),
					value = bind { key = propOpenAIApiKey },
					immediate = true,
					fill_horizontal = 1,
					height_in_lines = 1,
				},
			},
			f:row {
				f:push_button {
					title = LOC( "$$$/AiTagger/ApiKey/OpenAI/Setup=Get OpenAI API Key..." ),
					place_horizontal = 1,
					action = function( btn )
						LrHttp.openUrlInBrowser( "https://platform.openai.com/api-keys" )
					end,
				},
				f:push_button {
					title = LOC( "$$$/AiTagger/ApiKey/Clear=Clear" ),
					place_horizontal = 1,
					action = function( btn )
						propertyTable[ propOpenAIApiKey ] = ""
						clearApiKey( propertyTable, "openai" )
					end,
				},
			},
		},
		-- auto collections
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Options/Collections/Title=Auto Collections" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:checkbox {
					title = LOC( "$$$/AiTagger/Options/Collections/CreateAuto=Create automatic collections" ),
					value = bind { key = propCreateAutoCollections },
					fill_horizontal = 1,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Collections/Scheme=Collection Scheme:" ),
					width = share( propGeneralOptionsPromptWidth ),
					alignment = "right",
				},
				f:popup_menu {
					enabled = bind { key = propCreateAutoCollections },
					value = bind { key = propCollectionScheme },
					items = {
						{ title = LOC( "$$$/AiTagger/Options/Collections/ContentBased=Content-Based" ), value = "Content-Based" },
						{ title = LOC( "$$$/AiTagger/Options/Collections/QualityBased=Quality-Based" ), value = "Quality-Based" },
						{ title = LOC( "$$$/AiTagger/Options/Collections/LocationBased=Location-Based" ), value = "Location-Based" },
					},
				},
			},
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/Options/Collections/Help=Automatically organize AI-tagged photos into collections.\nContent-based groups by subject, Quality-based by AI confidence, Location-based by identified places." ),
					text_color = LrColor( 0.5, 0.5, 0.5 ),
					width_in_chars = 55,
				height_in_lines = 3,
				},
			},
		},
		-- versions
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/Versions/Title=AI Provider Status" ),
			synopsis = bind {
				keys = { propVersions, propAiProvider },
				operation = function( binder, values, fromTable )
					local versions = values[ propVersions ] or {}
					local provider = values[ propAiProvider ] or "gemini"
					if provider == "gemini" and versions.gemini then
						return versions.gemini.version or "Unknown"
					elseif provider == "ollama" and versions.ollama then
						return versions.ollama.version or "Unknown"
					elseif provider == "openai" and versions.openai then
						return versions.openai.version or "Unknown"
					else
						return "Unknown"
					end
				end,
			},
			spacing = f:label_spacing(),
			f:row {
				f:static_text {
					title = LOC( "$$$/AiTagger/Versions/Provider/Arrow=^U+25B6" )
				},
				f:static_text {
					title = bind {
						keys = { propVersions, propAiProvider },
						operation = function( binder, values, fromTable )
							local versions = values[ propVersions ] or {}
							local provider = values[ propAiProvider ] or "gemini"
							if provider == "gemini" and versions.gemini then
								return "Gemini: " .. (versions.gemini.version or "Unknown")
							elseif provider == "ollama" and versions.ollama then
								return "Ollama: " .. (versions.ollama.version or "Unknown")
							elseif provider == "openai" and versions.openai then
								return "OpenAI: " .. (versions.openai.version or "Unknown")
							else
								return "Status: Unknown"
							end
						end,
					},
					fill_horizontal = 1,
				},
			},
		},
		-- bug reporting
		{
			bind_to_object = propertyTable,
			title = LOC( "$$$/AiTagger/BugReport/Title=Bug Reporting" ),
			spacing = f:control_spacing(),
			f:row {
				fill_horizontal = 1,
				f:static_text {
					title = LOC( "$$$/AiTagger/BugReport/Description=Found a bug or have a feature request? Please report it on GitHub." ),
					width_in_chars = 55,
				height_in_lines = 2,
				},
			},
			f:row {
				fill_horizontal = 1,
				f:push_button {
					title = LOC( "$$$/AiTagger/BugReport/OpenGitHub=Report Bug on GitHub..." ),
					place_horizontal = 0.5,
					action = function( btn )
						LrHttp.openUrlInBrowser( "https://github.com/obelix74/lr-ai-image-tagger-docs/issues" )
					end,
				},
			},
		},
	}

end

--------------------------------------------------------------------------------

return {

	startDialog = startDialog,
	endDialog = endDialog,

	sectionsForTopOfDialog = sectionsForTopOfDialog,

}
