--[[----------------------------------------------------------------------------

 AI Image Tagger - OpenAI Integration
 Copyright 2025 Anand's Photography
 Updated for Lightroom Classic 2024 and OpenAI GPT-4V API

--------------------------------------------------------------------------------

OpenAIAPI.lua

------------------------------------------------------------------------------]]

local LrHttp = import "LrHttp"
local LrDate = import "LrDate"
local LrStringUtils = import "LrStringUtils"
local LrPrefs = import "LrPrefs"
local LrPasswords = import "LrPasswords"
local LrTasks = import "LrTasks"

local JSON = require "JSON"
require "Logger"
local AICommon = require "AICommon"

--------------------------------------------------------------------------------
-- OpenAI API Integration

OpenAIAPI = { }

local httpContentType = "Content-Type"
local httpAccept = "Accept"
local httpAuthorization = "Authorization"

local mimeTypeJson = "application/json"

local keyApiKey = "OpenAI.ApiKey"

local serviceBaseUri = "https://api.openai.com/v1"

--------------------------------------------------------------------------------
local serviceMaxRetries = 3
local defaultTimeout = 30000 -- 30 seconds in milliseconds

-- Get model from preferences (defaults to gpt-4o)
local function getServiceModel()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.openaiModel or "gpt-4o"
end

-- Get max tokens from preferences
local function getMaxTokens()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.openaiMaxTokens or 1000
end

-- Get temperature from preferences
local function getTemperature()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.openaiTemperature or 0.7
end

-- Get timeout from preferences
local function getTimeout()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.openaiTimeout or defaultTimeout
end

--------------------------------------------------------------------------------

function OpenAIAPI.getVersions()
	local versions = { }

	versions.openai = {
		version = "OpenAI API v1 (2024)",
	}

	return versions
end

function OpenAIAPI.storeApiKey( apiKey )
	math.randomseed( LrDate.currentTime() )
	local salt = tostring( math.random() * 100000 )
	local prefs = LrPrefs.prefsForPlugin()
	prefs.openaiSalt = salt
	LrPasswords.store( keyApiKey, apiKey, salt )
end

function OpenAIAPI.clearApiKey()
	local prefs = LrPrefs.prefsForPlugin()
	prefs.openaiSalt = nil
	LrPasswords.store( keyApiKey, "" )
end

function OpenAIAPI.getApiKey()
	local prefs = LrPrefs.prefsForPlugin()
	local salt = prefs.openaiSalt
	local apiKey = LrPasswords.retrieve( keyApiKey, salt )

	logger:infof( "OpenAI: getApiKey() - secure storage: %s, salt: %s",
		apiKey and "has key" or "empty", salt and "present" or "none" )

	return apiKey
end

function OpenAIAPI.hasApiKey()
	local apiKey = OpenAIAPI.getApiKey()
	local hasKey = apiKey ~= nil and apiKey ~= ""
	logger:infof( "OpenAI: hasApiKey() - result: %s", hasKey and "true" or "false" )
	return hasKey
end

--------------------------------------------------------------------------------

-- Test connection to OpenAI API
function OpenAIAPI.testConnection()
	logger:infof( "OpenAI: testConnection() called" )
	local apiKey = OpenAIAPI.getApiKey()
	if not apiKey or apiKey == "" then
		logger:errorf( "OpenAI: API key not configured in testConnection" )
		return { status = false, message = "API key not configured" }
	end

	logger:infof( "OpenAI: Testing connection with model %s", getServiceModel() )

	local reqHeaders = {
		{ field = httpContentType, value = mimeTypeJson },
		{ field = httpAccept, value = mimeTypeJson },
		{ field = httpAuthorization, value = "Bearer " .. apiKey },
	}

	local model = getServiceModel()
	local testRequest = {
		model = model,
		messages = {
			{
				role = "user",
				content = "Hello! Please respond with 'Connection successful' to test the API."
			}
		}
	}

	testRequest.max_tokens = 10

	local testReqBody = JSON:encode(testRequest)

	local serviceUri = string.format( "%s/chat/completions", serviceBaseUri )
	local resBody, resHeaders = LrHttp.post( serviceUri, testReqBody, reqHeaders, "POST", getTimeout() / 1000 )

	if not resBody then
		local errorMsg = "Network request failed: no response received"
		if resHeaders and resHeaders.error then
			errorMsg = string.format( "Network error: %s", resHeaders.error.name or "unknown error" )
		end
		logger:errorf( "OpenAI: %s", errorMsg )
		return { status = false, message = errorMsg }
	end

	if resHeaders.status == 401 then
		logger:errorf( "OpenAI: Invalid API key" )
		return { status = false, message = "Invalid API key" }
	elseif resHeaders.status == 403 then
		logger:errorf( "OpenAI: Access denied - check API key permissions" )
		return { status = false, message = "Access denied - check API key permissions" }
	elseif resHeaders.status == 404 then
		logger:errorf( "OpenAI: Model not found: %s", getServiceModel() )
		return { status = false, message = string.format( "Model not found: %s", getServiceModel() ) }
	elseif resHeaders.status == 429 then
		logger:errorf( "OpenAI: Rate limit exceeded" )
		return { status = false, message = "Rate limit exceeded - try again later" }
	elseif resHeaders.status == 200 then
		logger:infof( "OpenAI: Connection test successful" )
		return { status = true, message = "Connection successful" }
	else
		local errorMsg = string.format( "HTTP %d error", resHeaders.status )
		if resBody then
			local resJson = JSON:decode( resBody )
			if resJson and resJson.error and resJson.error.message then
				errorMsg = errorMsg .. ": " .. resJson.error.message
			end
		end
		logger:errorf( "OpenAI: %s", errorMsg )
		return { status = false, message = errorMsg }
	end
end

-- Parse OpenAI response and extract metadata
local function extractContentText( content )
	if type(content) == "string" then
		return content
	elseif type(content) ~= "table" then
		return tostring(content or "")
	end

	local parts = {}
	for _, part in ipairs(content) do
		if type(part) == "string" then
			table.insert(parts, part)
		elseif type(part) == "table" then
			if type(part.text) == "string" and part.text ~= "" then
				table.insert(parts, part.text)
			elseif type(part.content) == "string" and part.content ~= "" then
				table.insert(parts, part.content)
			end
		end
	end

	if #parts > 0 then
		return table.concat(parts, "\n")
	end

	return ""
end

local function parseOpenAIResponse( responseText )
	-- Ensure responseText is a string
	if type(responseText) ~= "string" then
		responseText = extractContentText(responseText)
	end

	if not responseText or responseText == "" then
		return AICommon.emptyResults()
	end

	local jsonText = responseText

	logger:infof( "OpenAI: Raw response: %s", string.sub(responseText, 1, 200) .. (string.len(responseText) > 200 and "..." or "") )

	-- Check if response is wrapped in markdown code blocks
	local codeBlockPattern = "```json%s*(.-)%s*```"
	local extractedJson = string.match(responseText, codeBlockPattern)
	if extractedJson then
		logger:infof( "OpenAI: Found JSON in ```json code block, extracting..." )
		jsonText = extractedJson
	else
		local genericCodeBlockPattern = "```%s*(.-)%s*```"
		extractedJson = string.match(responseText, genericCodeBlockPattern)
		if extractedJson then
			local trimmed = string.match(extractedJson, "^%s*(.-)%s*$")
			if string.find(trimmed, "^%s*{") and string.find(trimmed, "}%s*$") then
				logger:infof( "OpenAI: Found JSON-like content in generic code block, extracting..." )
				jsonText = extractedJson
			end
		end
	end

	jsonText = string.match(jsonText, "^%s*(.-)%s*$") -- trim whitespace

	logger:infof( "OpenAI: Attempting to parse JSON: %s", string.sub(jsonText, 1, 200) .. (string.len(jsonText) > 200 and "..." or "") )
	local success, analysisResult = pcall( function() return JSON:decode( jsonText ) end )

	if not success then
		logger:infof( "OpenAI: Initial JSON parsing failed, attempting robust extraction..." )
		local validJson = AICommon.extractValidJSON( jsonText )
		if validJson then
			logger:infof( "OpenAI: Extracted valid JSON: %s", string.sub(validJson, 1, 200) .. (string.len(validJson) > 200 and "..." or "") )
			success, analysisResult = pcall( function() return JSON:decode( validJson ) end )
		end
	end

	if success and analysisResult and type(analysisResult) == "table" then
		logger:infof( "OpenAI: JSON parsing successful" )
		return AICommon.buildAnalysisResult( analysisResult )
	else
		logger:errorf( "OpenAI: JSON parsing failed, falling back to text parsing" )
		return {
			title = "",
			caption = responseText:sub(1, 100),
			headline = "",
			instructions = "",
			copyright = "",
			location = "",
			keywords = {}
		}
	end
end

function OpenAIAPI.analyze( fileName, photo, photoObject )
	local attempts = 0
	while attempts <= serviceMaxRetries do
		-- Add exponential backoff delay for retries to avoid overwhelming API
		if attempts > 0 then
			local delay = math.min(2 ^ attempts, 8) -- Exponential backoff: 2s, 4s, 8s max
			logger:infof("OpenAI: Retry attempt %d for %s after %d second delay", attempts, fileName, delay)
			LrTasks.sleep(delay)
		end

		local apiKey = OpenAIAPI.getApiKey()
		if not apiKey or apiKey == "" then
			logger:warnf( "OpenAI: API key missing" )
			return { status = false, message = "API key missing" }
		end

		local reqHeaders = {
			{ field = httpContentType, value = mimeTypeJson },
			{ field = httpAccept, value = mimeTypeJson },
			{ field = httpAuthorization, value = "Bearer " .. apiKey },
		}

		-- Build prompt with optional metadata
		local prompt = AICommon.getAnalysisPrompt()
		prompt = AICommon.appendMetadataToPrompt( prompt, photoObject )

		-- Validate and encode image data
		if not photo or photo == "" then
			local errorMsg = string.format( "Invalid image data for %s: thumbnail generation failed", fileName or "unknown file" )
			logger:errorf( "OpenAI: %s", errorMsg )
			return { status = false, message = errorMsg }
		end

		local base64Image = LrStringUtils.encodeBase64( photo )

		-- Create the request body for OpenAI Chat Completions API
		local model = getServiceModel()
		local requestBody = {
			model = model,
			messages = {
				{
					role = "user",
					content = {
						{
							type = "text",
							text = prompt
						},
						{
							type = "image_url",
							image_url = {
								url = "data:image/jpeg;base64," .. base64Image
							}
						}
					}
				}
			}
		}

		requestBody.max_tokens = getMaxTokens()
		requestBody.temperature = getTemperature()

		local reqBody = JSON:encode(requestBody)

		local serviceUri = string.format( "%s/chat/completions", serviceBaseUri )

		-- Make HTTP call
		local resBody, resHeaders = LrHttp.post( serviceUri, reqBody, reqHeaders, "POST", getTimeout() / 1000 )

		if not resBody then
			local errorMsg = "Network request failed: no response received"
			if resHeaders and resHeaders.error then
				errorMsg = string.format( "Network error: %s", resHeaders.error.name or "unknown error" )
			end

			if attempts < serviceMaxRetries then
				logger:warnf( "OpenAI: %s (attempt %d/%d)", errorMsg, attempts + 1, serviceMaxRetries + 1 )
			else
				logger:errorf( "OpenAI: %s", errorMsg )
				return { status = false, message = errorMsg }
			end

		elseif resHeaders.status == 401 then
			logger:warnf( "OpenAI: authorization failure, invalid API key" )
			return { status = false, message = "Invalid API key" }
		elseif resHeaders.status == 429 then
			-- Rate limit - use retry-after header if available
			local retryAfter = resHeaders["retry-after"] or "60"
			local retryDelay = math.min(tonumber(retryAfter) or 60, 60)
			if attempts < serviceMaxRetries then
				logger:warnf( "OpenAI: rate limit exceeded, retrying in %d seconds", retryDelay )
				LrTasks.sleep( retryDelay )
			else
				return { status = false, message = "Rate limit exceeded" }
			end
		elseif resHeaders.status == 200 then
			local resJson = JSON:decode( resBody )

			logger:infof( "OpenAI: Response body length: %d", resBody and string.len(resBody) or 0 )
			logger:infof( "OpenAI: Has choices: %s, choice count: %d",
				resJson.choices and "true" or "false",
				resJson.choices and #resJson.choices or 0 )

			if resJson.choices and #resJson.choices > 0 then
				local choice = resJson.choices[1]

				logger:infof( "OpenAI: Choice finish_reason: %s", choice.finish_reason or "nil" )
				logger:infof( "OpenAI: Choice has message: %s", choice.message and "true" or "false" )
				if choice.message then
					logger:infof( "OpenAI: Message has content: %s", choice.message.content and "true" or "false" )
					logger:infof( "OpenAI: Message has refusal: %s", choice.message.refusal and "true" or "false" )

					-- Check for refusal first (newer models)
					if choice.message.refusal then
						local refusalMsg = choice.message.refusal
						logger:warnf( "OpenAI: Model refused request: %s", refusalMsg )
						return { status = false, message = "Model refused: " .. refusalMsg }
					end

					if choice.message.content then
						logger:infof( "OpenAI: Content type: %s", type(choice.message.content) )
						local preview = extractContentText( choice.message.content )
						logger:infof( "OpenAI: Content preview: %s",
							string.sub(preview or "", 1, 200) )
					end
				end

				if choice.message and choice.message.content then
					local results = { status = true }
					local analysisResult = parseOpenAIResponse( choice.message.content )

					results.title = analysisResult.title
					results.caption = analysisResult.caption
					results.headline = analysisResult.headline
					results.instructions = analysisResult.instructions
					results.copyright = analysisResult.copyright
					results.location = analysisResult.location
					results.keywords = analysisResult.keywords

					return results
				else
					logger:errorf( "OpenAI: Invalid response structure - choice: %s",
						choice and "present" or "nil" )
					if choice then
						logger:errorf( "OpenAI: Choice structure: message=%s, content=%s, refusal=%s",
							choice.message and "present" or "nil",
							choice.message and choice.message.content and "present" or "nil",
							choice.message and choice.message.refusal and "present" or "nil" )
					end
					return { status = false, message = "Invalid response structure: no content in message" }
				end
			else
				logger:errorf( "OpenAI: No choices in response" )
				logger:errorf( "OpenAI: Response keys: %s", resBody and string.sub(resBody, 1, 500) or "empty" )
				return { status = false, message = "No response choices" }
			end
		else
			-- Parse error response
			local errorMsg = string.format( "HTTP %d error", resHeaders.status )
			local errorResJson = nil
			if resBody and resBody ~= "" then
				local success, parsed = pcall( function() return JSON:decode( resBody ) end )
				if success then
					errorResJson = parsed
				else
					logger:warnf( "OpenAI: Failed to parse error response body: %s", string.sub(resBody, 1, 200) )
				end
			end

			if errorResJson and errorResJson.error and errorResJson.error.message then
				errorMsg = errorMsg .. ": " .. errorResJson.error.message
			end

			logger:warnf( "OpenAI: HTTP %d - Response body: %s", resHeaders.status, resBody and string.sub(resBody, 1, 500) or "empty" )

			-- Check if this is a retriable error (quota, temporary issues)
			local isRetriable = false
			if resHeaders.status == 503 or
			   (errorMsg and (errorMsg:find("quota") or errorMsg:find("rate limit") or errorMsg:find("retry"))) then
				isRetriable = true
			end

			if isRetriable and attempts < serviceMaxRetries then
				logger:warnf( "OpenAI: retriable error on attempt %d/%d: %s", attempts + 1, serviceMaxRetries + 1, errorMsg )
			else
				logger:errorf( "OpenAI: analyze API failed: %s", errorMsg )
				return { status = false, message = errorMsg }
			end
		end

		attempts = attempts + 1
	end

	return { status = false, message = "Maximum retries exceeded" }
end

-- Batch processing with rate limiting
function OpenAIAPI.analyzeBatch( photos, progressCallback )
	return AICommon.analyzeBatch( OpenAIAPI.analyze, photos, progressCallback )
end

-- Get default prompt for UI display
function OpenAIAPI.getDefaultPrompt()
	return AICommon.getDefaultPrompt()
end

-- Load prompt from text file
function OpenAIAPI.loadPromptFromFile( filePath )
	return AICommon.loadPromptFromFile( filePath )
end

-- Get available prompt presets
function OpenAIAPI.getPromptPresets()
	return AICommon.getPromptPresets()
end

-- Get preset names for UI dropdown
function OpenAIAPI.getPresetNames()
	return AICommon.getPresetNames()
end

-- Get a specific preset by name
function OpenAIAPI.getPreset( name )
	return AICommon.getPreset( name )
end
