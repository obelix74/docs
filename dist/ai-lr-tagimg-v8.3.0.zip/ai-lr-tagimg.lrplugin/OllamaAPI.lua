--[[----------------------------------------------------------------------------

 AI Image Tagger - Ollama Integration
 Copyright 2025 Anand's Photography
 Updated for Lightroom Classic 2024 and Ollama AI API

--------------------------------------------------------------------------------

OllamaAPI.lua

------------------------------------------------------------------------------]]

local LrHttp = import "LrHttp"
local LrStringUtils = import "LrStringUtils"
local LrPrefs = import "LrPrefs"
local LrTasks = import "LrTasks"

local JSON = require "JSON"
require "Logger"
local AICommon = require "AICommon"

--------------------------------------------------------------------------------
-- Ollama AI API

OllamaAPI = { }

local httpContentType = "Content-Type"
local httpAccept = "Accept"

local mimeTypeJson = "application/json"

local serviceMaxRetries = 2
local defaultTimeout = 300000 -- 5 minutes in milliseconds

--------------------------------------------------------------------------------
-- Ollama-specific JSON fixup helpers

-- Remove trailing commas from JSON (common Ollama error)
local function removeTrailingCommas(jsonText)
	jsonText = string.gsub(jsonText, ",%s*}", "}")
	jsonText = string.gsub(jsonText, ",%s*]", "]")
	return jsonText
end

-- Fix malformed keywords object where Ollama returns { "key1", "key2" } instead of array or proper object
local function fixMalformedKeywordsObject(jsonText)
	local keywordsPattern = '"keywords"%s*:%s*{'
	local keywordsStart, openBracePos = string.find(jsonText, keywordsPattern)
	if not keywordsStart then
		return jsonText
	end

	local depth = 0
	local inString = false
	local escaped = false
	local closingBrace = nil

	for i = openBracePos + 1, string.len(jsonText) do
		local char = string.sub(jsonText, i, i)

		if escaped then
			escaped = false
		elseif char == "\\" then
			escaped = true
		elseif char == '"' and not escaped then
			inString = not inString
		elseif not inString then
			if char == "{" then
				depth = depth + 1
			elseif char == "}" then
				if depth == 0 then
					closingBrace = i
					break
				else
					depth = depth - 1
				end
			end
		end
	end

	if not closingBrace then
		return jsonText
	end

	local content = string.sub(jsonText, openBracePos + 1, closingBrace - 1)

	local cleaned = ""
	local inStr = false
	local esc = false
	for i = 1, string.len(content) do
		local c = string.sub(content, i, i)
		if esc then
			esc = false
		elseif c == "\\" then
			esc = true
		elseif c == '"' then
			inStr = not inStr
		elseif not inStr then
			cleaned = cleaned .. c
		end
	end

	if not string.find(cleaned, ':') then
		local before = string.sub(jsonText, 1, openBracePos - 1)
		local middle = string.sub(jsonText, openBracePos + 1, closingBrace - 1)
		local after = string.sub(jsonText, closingBrace + 1)

		jsonText = before .. "[" .. middle .. "]" .. after
		logger:infof("OllamaAPI: Fixed malformed keywords object -> array")
	end

	return jsonText
end

-- Extract text from Ollama chat content payloads.
-- Some models return `message.content` as structured arrays/objects instead of plain strings.
local function extractResponseText(content)
	if type(content) == "string" then
		return content
	elseif type(content) ~= "table" then
		return tostring(content or "")
	end

	-- Common shape: { { type = "text", text = "..." }, ... }
	if #content > 0 then
		local parts = {}
		for _, part in ipairs(content) do
			if type(part) == "string" then
				table.insert(parts, part)
			elseif type(part) == "table" then
				if type(part.text) == "string" and part.text ~= "" then
					table.insert(parts, part.text)
				elseif type(part.content) == "string" and part.content ~= "" then
					table.insert(parts, part.content)
				end
			end
		end

		if #parts > 0 then
			return table.concat(parts, "\n")
		end
	end

	if type(content.text) == "string" and content.text ~= "" then
		return content.text
	end
	if type(content.content) == "string" and content.content ~= "" then
		return content.content
	end

	return ""
end

--------------------------------------------------------------------------------

function OllamaAPI.getVersions()
	local versions = { }

	versions.ollama = {
		version = "Ollama AI API (2024)",
	}

	return versions
end

function OllamaAPI.getBaseUrl()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.ollamaBaseUrl or "http://localhost:11434"
end

function OllamaAPI.setBaseUrl( baseUrl )
	local prefs = LrPrefs.prefsForPlugin()
	prefs.ollamaBaseUrl = baseUrl
end

function OllamaAPI.getModel()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.ollamaModel or ""
end

function OllamaAPI.setModel( model )
	local prefs = LrPrefs.prefsForPlugin()
	prefs.ollamaModel = model
end

function OllamaAPI.getTimeout()
	local prefs = LrPrefs.prefsForPlugin()
	return prefs.ollamaTimeout or defaultTimeout
end

function OllamaAPI.setTimeout( timeout )
	local prefs = LrPrefs.prefsForPlugin()
	prefs.ollamaTimeout = timeout
end

-- Fetch list of installed models from the Ollama server
-- Returns a table of { title, value } items suitable for a popup_menu, or nil on error
function OllamaAPI.fetchInstalledModels()
	local baseUrl = OllamaAPI.getBaseUrl()
	logger:infof( "OllamaAPI: Fetching installed models from %s", baseUrl )

	local reqHeaders = {
		{ field = httpContentType, value = mimeTypeJson },
		{ field = httpAccept, value = mimeTypeJson },
	}

	local serviceUri = string.format( "%s/api/tags", baseUrl )
	local resBody, resHeaders = LrHttp.get( serviceUri, reqHeaders )

	if not resBody or not resHeaders or resHeaders.status ~= 200 then
		logger:errorf( "OllamaAPI: Failed to fetch installed models (status %s)", tostring(resHeaders and resHeaders.status) )
		return nil
	end

	local resJson = JSON:decode( resBody )
	if not resJson or not resJson.models then
		logger:errorf( "OllamaAPI: Invalid /api/tags response" )
		return nil
	end

	local items = {}
	for _, modelInfo in ipairs( resJson.models ) do
		local name = modelInfo.name or ""
		if name ~= "" then
			table.insert( items, { title = name, value = name } )
		end
	end

	logger:infof( "OllamaAPI: Found %d installed models", #items )
	return items
end

-- Test connection to Ollama server
function OllamaAPI.testConnection()
	local baseUrl = OllamaAPI.getBaseUrl()
	local model = OllamaAPI.getModel()

	logger:infof( "OllamaAPI: Testing connection to %s with model %s", baseUrl, model )

	local reqHeaders = {
		{ field = httpContentType, value = mimeTypeJson },
		{ field = httpAccept, value = mimeTypeJson },
	}

	local serviceUri = string.format( "%s/api/tags", baseUrl )
	local resBody, resHeaders = LrHttp.get( serviceUri, reqHeaders )

	if not resBody or not resHeaders or resHeaders.status ~= 200 then
		local errorMsg = "Ollama server not accessible"
		if resHeaders and resHeaders.error then
			errorMsg = string.format( "Connection error: %s", resHeaders.error.name or "unknown error" )
		elseif resHeaders and resHeaders.status then
			errorMsg = string.format( "HTTP %d: Server not accessible", resHeaders.status )
		end
		logger:errorf( "OllamaAPI: %s", errorMsg )
		return { status = false, message = errorMsg }
	end

	local resJson = JSON:decode( resBody )
	if not resJson or not resJson.models then
		logger:errorf( "OllamaAPI: Invalid response from server" )
		return { status = false, message = "Invalid response from Ollama server" }
	end

	-- If no model is configured yet, just confirm the server is reachable
	if not model or model == "" then
		local availableModels = {}
		for _, modelInfo in ipairs( resJson.models ) do
			table.insert( availableModels, modelInfo.name )
		end
		logger:infof( "OllamaAPI: Server reachable. No model configured yet. Available: %s", table.concat( availableModels, ", " ) )
		return { status = true, message = "Connection successful" }
	end

	local modelExists = false
	local availableModels = {}
	local modelBase = string.gsub(model, ":latest$", "")

	for _, modelInfo in ipairs( resJson.models ) do
		table.insert( availableModels, modelInfo.name )
		if modelInfo.name == model or string.find( modelInfo.name, modelBase, 1, true ) then
			modelExists = true
		end
	end

	if not modelExists then
		local errorMsg = string.format( "Model '%s' not found. Available models: %s", model, table.concat( availableModels, ", " ) )
		logger:errorf( "OllamaAPI: %s", errorMsg )
		return { status = false, message = errorMsg }
	end

	logger:infof( "OllamaAPI: Connection test successful - model %s is available", model )
	return { status = true, message = "Connection successful" }
end

--------------------------------------------------------------------------------

-- Parse Ollama response (handles both JSON and text responses)
local function parseResponse( responseText )
	-- Ensure responseText is a string
	if type(responseText) == "table" then
		logger:warnf( "OllamaAPI: parseResponse received table content; attempting structured text extraction" )
		responseText = extractResponseText(responseText)
	end

	if not responseText or responseText == "" then
		return AICommon.emptyResults()
	end

	-- Extract JSON from markdown code blocks if present
	local jsonText = responseText

	logger:infof( "OllamaAPI: Raw response: %s", string.sub(responseText, 1, 200) .. (string.len(responseText) > 200 and "..." or "") )

	-- Check if response is wrapped in markdown code blocks - try multiple patterns
	local codeBlockPattern = "```json%s*(.-)%s*```"
	local extractedJson = string.match(responseText, codeBlockPattern)
	if extractedJson then
		logger:infof( "OllamaAPI: Found JSON in ```json code block, extracting..." )
		jsonText = extractedJson
	else
		codeBlockPattern = "```json\n(.-)```"
		extractedJson = string.match(responseText, codeBlockPattern)
		if extractedJson then
			logger:infof( "OllamaAPI: Found JSON in ```json\\n code block, extracting..." )
			jsonText = extractedJson
		else
			local genericCodeBlockPattern = "```%s*(.-)%s*```"
			extractedJson = string.match(responseText, genericCodeBlockPattern)
			if extractedJson then
				local trimmed = string.match(extractedJson, "^%s*(.-)%s*$")
				if string.find(trimmed, "^%s*{") and string.find(trimmed, "}%s*$") then
					logger:infof( "OllamaAPI: Found JSON-like content in generic code block, extracting..." )
					jsonText = extractedJson
				end
			else
				genericCodeBlockPattern = "```.-\n(.-)\n```"
				extractedJson = string.match(responseText, genericCodeBlockPattern)
				if extractedJson then
					local trimmed = string.match(extractedJson, "^%s*(.-)%s*$")
					if string.find(trimmed, "^%s*{") and string.find(trimmed, "}%s*$") then
						logger:infof( "OllamaAPI: Found JSON-like content in multiline code block, extracting..." )
						jsonText = extractedJson
					end
				end
			end
		end
	end

	jsonText = string.match(jsonText, "^%s*(.-)%s*$") -- trim whitespace

	-- Apply Ollama-specific JSON fixups
	jsonText = removeTrailingCommas(jsonText)
	jsonText = fixMalformedKeywordsObject(jsonText)

	logger:infof( "OllamaAPI: Attempting to parse JSON: %s", string.sub(jsonText, 1, 200) .. (string.len(jsonText) > 200 and "..." or "") )
	local success, analysisResult = pcall( function() return JSON:decode( jsonText ) end )

	if not success then
		logger:infof( "OllamaAPI: Initial JSON parsing failed, attempting robust extraction..." )
		local validJson = AICommon.extractValidJSON( jsonText )
		if validJson then
			validJson = removeTrailingCommas(validJson)
			validJson = fixMalformedKeywordsObject(validJson)
			logger:infof( "OllamaAPI: Extracted valid JSON: %s", string.sub(validJson, 1, 200) .. (string.len(validJson) > 200 and "..." or "") )
			success, analysisResult = pcall( function() return JSON:decode( validJson ) end )
		end
	end

	if success and analysisResult and type(analysisResult) == "table" then
		logger:infof( "OllamaAPI: JSON parsing successful" )
		local results = AICommon.buildAnalysisResult( analysisResult )
		logger:infof( "OllamaAPI: Extracted %d keywords", #results.keywords )
		return results
	else
		-- Fallback to text parsing
		if not success then
			logger:errorf( "OllamaAPI: JSON parsing failed with error: %s", tostring(analysisResult) )
		else
			logger:errorf( "OllamaAPI: JSON parsing succeeded but result is not valid: %s", tostring(analysisResult) )
		end
		logger:infof( "OllamaAPI: Falling back to text parsing" )

		local lines = {}
		for line in string.gmatch(responseText, "[^\r\n]+") do
			local trimmed = string.match(line, "^%s*(.-)%s*$")
			if trimmed ~= "" then
				table.insert(lines, trimmed)
			end
		end

		local results = AICommon.emptyResults()

		-- Look for structured patterns in the response
		for _, line in ipairs(lines) do
			local lowerLine = string.lower(line)

			if string.find(lowerLine, "title:") then
				results.title = string.match(line, "title:%s*(.+)") or ""
			elseif string.find(lowerLine, "caption:") then
				results.caption = string.match(line, "caption:%s*(.+)") or ""
			elseif string.find(lowerLine, "headline:") or string.find(lowerLine, "description:") then
				results.headline = string.match(line, "headline:%s*(.+)") or string.match(line, "description:%s*(.+)") or ""
			elseif string.find(lowerLine, "instructions:") then
				results.instructions = string.match(line, "instructions:%s*(.+)") or ""
			elseif string.find(lowerLine, "location:") then
				results.location = string.match(line, "location:%s*(.+)") or ""
			elseif string.find(lowerLine, "keywords:") or string.find(lowerLine, "tags:") then
				local keywordText = string.match(line, "keywords:%s*(.+)") or string.match(line, "tags:%s*(.+)") or ""
				for keyword in string.gmatch(keywordText, "([^,]+)") do
					local trimmed = string.match(keyword, "^%s*(.-)%s*$")
					if trimmed ~= "" then
						table.insert(results.keywords, { description = trimmed, selected = true })
					end
				end
			end
		end

		-- If we still don't have basic fields, use the first substantial lines
		if results.caption == "" and #lines > 0 then
			results.caption = lines[1]
		end
		if results.headline == "" and results.caption ~= "" then
			results.headline = results.caption
		end

		-- Generate some basic keywords if none were found
		if #results.keywords == 0 then
			local allText = string.lower(responseText)
			local commonWords = { "the", "and", "of", "to", "a", "in", "is", "it", "you", "that", "he", "was", "for", "on", "are", "as", "with", "his", "they", "i", "at", "be", "this", "have", "from", "or", "one", "had", "by", "word", "but", "not", "what", "all", "were", "we", "when", "your", "can", "said", "there", "each", "which", "she", "do", "how", "their", "if", "will", "up", "other", "about", "out", "many", "then", "them", "these", "so", "some", "her", "would", "make", "like", "into", "him", "has", "two", "more", "very", "time", "when", "come", "its", "now", "over", "think", "also", "work", "life", "only", "still", "should", "after", "being", "made", "before", "here", "through", "much", "where", "well", "get", "me", "own", "say", "may", "use", "than", "man", "day" }
			local wordSet = {}
			for _, word in ipairs(commonWords) do
				wordSet[word] = true
			end

			local words = {}
			for word in string.gmatch(allText, "%w+") do
				if string.len(word) > 3 and not wordSet[word] then
					words[word] = true
				end
			end

			local keywordList = {}
			for word, _ in pairs(words) do
				table.insert(keywordList, word)
				if #keywordList >= 5 then break end
			end

			for _, keyword in ipairs(keywordList) do
				table.insert(results.keywords, { description = keyword, selected = true })
			end
		end

		return results
	end
end

function OllamaAPI.analyze( fileName, photo, photoObject )
	local attempts = 0
	local baseUrl = OllamaAPI.getBaseUrl()
	local model = OllamaAPI.getModel()
	local timeout = OllamaAPI.getTimeout()

	if not model or model == "" then
		local errorMsg = "No Ollama model selected. Please open Plugin Manager > Ollama Configuration and select a model."
		logger:errorf( "OllamaAPI: %s", errorMsg )
		return { status = false, message = errorMsg }
	end

	while attempts <= serviceMaxRetries do
		-- Add exponential backoff delay for retries to avoid overwhelming API
		if attempts > 0 then
			local delay = math.min(2 ^ attempts, 8) -- Exponential backoff: 2s, 4s, 8s max
			logger:infof("OllamaAPI: Retry attempt %d for %s after %d second delay", attempts, fileName, delay)
			LrTasks.sleep(delay)
		end

		local reqHeaders = {
			{ field = httpContentType, value = mimeTypeJson },
			{ field = httpAccept, value = mimeTypeJson },
		}

		-- Build prompt with optional metadata
		local prompt = AICommon.getAnalysisPrompt()
		prompt = AICommon.appendMetadataToPrompt( prompt, photoObject )

		-- Validate image data before encoding
		if not photo or photo == "" then
			local errorMsg = string.format( "Invalid image data for %s: thumbnail generation failed", fileName or "unknown file" )
			logger:errorf( "OllamaAPI: %s", errorMsg )
			return { status = false, message = errorMsg }
		end

		-- Encode the image data as base64
		local base64Image
		local encodeSuccess, result = pcall( function() return LrStringUtils.encodeBase64( photo ) end )
		if not encodeSuccess then
			local errorMsg = string.format( "Failed to encode image data for %s: %s", fileName or "unknown file", tostring(result) )
			logger:errorf( "OllamaAPI: %s", errorMsg )
			return { status = false, message = errorMsg }
		end
		base64Image = result

		-- Create the request body for Ollama Chat API
		local reqBody = JSON:encode {
			model = model,
			messages = {
				{
					role = "user",
					content = prompt,
					images = { base64Image }
				}
			},
			stream = false,
			options = {
				temperature = 0.7,
				num_predict = 4096
			}
		}

		local serviceUri = string.format( "%s/api/chat", baseUrl )

		logger:infof( "OllamaAPI: Request attempt %d/%d to %s with model %s", attempts + 1, serviceMaxRetries + 1, baseUrl, model )

		-- Make HTTP call
		local resBody, resHeaders = LrHttp.post( serviceUri, reqBody, reqHeaders, "POST", timeout / 1000 )

		if not resBody or not resHeaders then
			local errorMsg = "Network request failed: no response received"
			if resHeaders and resHeaders.error then
				errorMsg = string.format( "Network error: %s", resHeaders.error.name or "unknown error" )
			end
			logger:errorf( "OllamaAPI: %s", errorMsg )

			if attempts >= serviceMaxRetries then
				return { status = false, message = errorMsg }
			end
		elseif resHeaders.status == 200 then
			local resJson = JSON:decode( resBody )
			-- Chat API returns { message: { role: "assistant", content: "..." } }
			local responseText = nil

			-- Log all response message fields for debugging
			if resJson and resJson.message then
				local keys = {}
				for k, _ in pairs(resJson.message) do table.insert(keys, k) end
				logger:infof( "OllamaAPI: Response message fields: %s", table.concat(keys, ", ") )
			end

			-- Log thinking field for debugging (qwen3-vl and other thinking models)
			if resJson and resJson.message and resJson.message.thinking then
				logger:infof( "OllamaAPI: Model used thinking (%d chars)", string.len(tostring(resJson.message.thinking)) )
			end

			if resJson and resJson.message and resJson.message.content then
				responseText = extractResponseText(resJson.message.content)
			elseif resJson and resJson.response then
				-- Fallback for older Ollama versions using /api/generate format
				responseText = extractResponseText(resJson.response)
			end

			-- Strip <think>...</think> tags from response (qwen3-vl, deepseek, etc.)
			if type(responseText) == "string" then
				responseText = string.gsub(responseText, "<think>.-</think>", "")
				responseText = string.match(responseText, "^%s*(.-)%s*$") or ""
			end

			-- If content is empty but thinking was present, warn about token exhaustion
			if (not responseText or responseText == "") and resJson and resJson.message and resJson.message.thinking then
				logger:warnf( "OllamaAPI: Response content is empty but model produced %d chars of thinking. The model may have exhausted its token budget on reasoning. Try increasing num_predict or using a non-thinking model.",
					string.len(tostring(resJson.message.thinking)) )
			end

			if responseText then
				local results = { status = true }

				logger:infof( "OllamaAPI: Response type: %s", type(responseText) )
				if type(responseText) == "string" then
					logger:infof( "OllamaAPI: Response content: %s", string.sub(responseText, 1, 200) .. (string.len(responseText) > 200 and "..." or "") )
				else
					logger:infof( "OllamaAPI: Response is not a string: %s", tostring(responseText) )
				end

				local analysisResult = parseResponse( responseText )

				results.title = analysisResult.title or ""
				results.caption = analysisResult.caption or ""
				results.headline = analysisResult.headline or ""
				results.instructions = analysisResult.instructions or ""
				results.copyright = analysisResult.copyright or ""
				results.location = analysisResult.location or ""
				results.keywords = analysisResult.keywords or {}

				logger:infof( "OllamaAPI: Analysis successful - title: %s, caption: %s, keywords: %d",
					results.title ~= "" and "yes" or "no",
					results.caption ~= "" and "yes" or "no",
					#results.keywords )

				return results
			else
				local errorMsg = "Invalid response format from Ollama"
				logger:errorf( "OllamaAPI: %s", errorMsg )
				return { status = false, message = errorMsg }
			end
		else
			local errorMsg = "Unknown error"
			if resHeaders.status then
				errorMsg = string.format( "HTTP %d error", resHeaders.status )
			end
			if resBody then
				local resJson = JSON:decode( resBody )
				if resJson and resJson.error then
					if type( resJson.error ) == "string" then
						errorMsg = errorMsg .. ": " .. resJson.error
					elseif type( resJson.error ) == "table" and resJson.error.message then
						errorMsg = errorMsg .. ": " .. resJson.error.message
					else
						errorMsg = errorMsg .. ": " .. tostring( resJson.error )
					end
				end
			end
			logger:errorf( "OllamaAPI: %s", errorMsg )

			if attempts >= serviceMaxRetries then
				return { status = false, message = errorMsg }
			end
		end

		attempts = attempts + 1
	end

	return { status = false, message = "Maximum retries exceeded" }
end

-- Batch processing with rate limiting
function OllamaAPI.analyzeBatch( photos, progressCallback )
	return AICommon.analyzeBatch( OllamaAPI.analyze, photos, progressCallback )
end

-- Get default prompt for UI display
function OllamaAPI.getDefaultPrompt()
	return AICommon.getDefaultPrompt()
end

-- Load prompt from text file
function OllamaAPI.loadPromptFromFile( filePath )
	return AICommon.loadPromptFromFile( filePath )
end

-- Get available prompt presets
function OllamaAPI.getPromptPresets()
	return AICommon.getPromptPresets()
end

-- Get preset names for UI dropdown
function OllamaAPI.getPresetNames()
	return AICommon.getPresetNames()
end

-- Get a specific preset by name
function OllamaAPI.getPreset( name )
	return AICommon.getPreset( name )
end
