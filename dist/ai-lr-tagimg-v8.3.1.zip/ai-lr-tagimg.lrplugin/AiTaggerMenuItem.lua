--[[----------------------------------------------------------------------------

 AI Image Tagger
 Copyright 2024 Anand Kumar Sankaran
 Updated for Lightroom Classic 2024 and Gemini AI

--------------------------------------------------------------------------------

AiTaggerMenuItem.lua

------------------------------------------------------------------------------]]

local LrApplication = import "LrApplication"
local LrPrefs = import "LrPrefs"
local LrTasks = import "LrTasks"
local LrHttp = import "LrHttp"
local LrDate = import "LrDate"
local LrColor = import "LrColor"
local LrStringUtils = import "LrStringUtils"
local LrFunctionContext = import "LrFunctionContext"
local LrProgressScope = import "LrProgressScope"
local LrDialogs = import "LrDialogs"
local LrBinding = import "LrBinding"
local LrView = import "LrView"
local LrPathUtils = import "LrPathUtils"
local LrFileUtils = import "LrFileUtils"
local bind = LrView.bind
local share = LrView.share

--------------------------------------------------------------------------------

local inspect = require "inspect"
require "Logger"
require "AIProviderFactory"

--------------------------------------------------------------------------------

local prefs = LrPrefs.prefsForPlugin()

-- Collection management constants
local KEYWORD_COLLECTIONS = {
	["Landscapes"] = {"landscape", "nature", "outdoor", "mountain", "ocean", "forest", "desert", "valley", "lake", "river"},
	["People"] = {"person", "people", "portrait", "face", "family", "child", "baby", "man", "woman"},
	["Animals"] = {"animal", "dog", "cat", "bird", "horse", "wildlife", "pet", "farm", "zoo"},
	["Architecture"] = {"building", "house", "church", "bridge", "tower", "architecture", "urban", "city"},
	["Food"] = {"food", "meal", "restaurant", "cooking", "kitchen", "fruit", "vegetable", "drink"},
	["Events"] = {"wedding", "party", "birthday", "celebration", "festival", "concert", "graduation"},
	["Sports"] = {"sport", "football", "basketball", "tennis", "running", "swimming", "cycling", "golf"},
	["Travel"] = {"travel", "vacation", "tourist", "hotel", "airport", "train", "car", "road"}
}

local LOCATION_COLLECTIONS = {
	["National Parks"] = {"national park", "yosemite", "yellowstone", "grand canyon", "zion"},
	["Cities"] = {"city", "urban", "downtown", "street", "skyline", "new york", "san francisco", "los angeles"},
	["Landmarks"] = {"landmark", "monument", "statue", "historic", "famous", "tower", "bridge"},
	["Indoor"] = {"indoor", "inside", "room", "house", "building", "interior"},
	["Outdoor"] = {"outdoor", "outside", "garden", "park", "field", "forest"},
	["Beach"] = {"beach", "ocean", "sea", "sand", "coast", "shore", "wave"},
	["Mountains"] = {"mountain", "hill", "peak", "summit", "alpine", "hiking", "climbing"}
}

local propPhotos = "photos"
local propCurrentPhotoIndex = "currentPhotoIndex"
local propCurrentPhotoName = "currentPhotoName"
local propTotalPhotos = "totalPhotos"
local propStartTime = "startTime"
local propElapsedTime = "elapsedTime"
local propConsumedTime = "consumedTime"
local propMaxKeywords = "maxKeywords"
local propTitle = "title"
local propCaption = "caption"
local propHeadline = "headline"
local propInstructions = "instructions"
local propLocation = "location"
local propCopyright = "copyright"

local function propKeywordTitle( i )
	return string.format( "keywordTitle%d", i )
end
local function propKeywordSelected( i )
	return string.format( "keywordSelected%d", i )
end

--------------------------------------------------------------------------------

-- Hierarchical Keyword Utility Functions

-- Parse hierarchical keyword string into components
-- Example: "Animals > Mammals > Dogs" -> {"Animals", "Mammals", "Dogs"}
local function parseKeywordHierarchy(keywordString)
	if not keywordString or keywordString == "" then
		return {}
	end

	local LrPrefs = import "LrPrefs"
	local prefs = LrPrefs.prefsForPlugin()
	local separator = prefs.keywordHierarchySeparator or " > "
	local hierarchy = {}

	-- Split by separator using string.find and string.sub
	local startPos = 1
	local separatorLen = string.len(separator)

	while true do
		local sepStart, sepEnd = string.find(keywordString, separator, startPos, true) -- plain text search

		if sepStart then
			-- Extract part before separator
			local part = string.sub(keywordString, startPos, sepStart - 1)
			local trimmed = string.match(part, "^%s*(.-)%s*$") -- trim whitespace
			if trimmed and trimmed ~= "" then
				table.insert(hierarchy, trimmed)
			end
			startPos = sepEnd + 1
		else
			-- Extract final part after last separator
			local part = string.sub(keywordString, startPos)
			local trimmed = string.match(part, "^%s*(.-)%s*$") -- trim whitespace
			if trimmed and trimmed ~= "" then
				table.insert(hierarchy, trimmed)
			end
			break
		end
	end

	-- Limit hierarchy depth
	local maxDepth = prefs.maxHierarchyDepth or 4
	if #hierarchy > maxDepth then
		logger:tracef("Keyword hierarchy too deep (%d levels), truncating to %d: %s", #hierarchy, maxDepth, keywordString)
		local truncated = {}
		for i = 1, maxDepth do
			table.insert(truncated, hierarchy[i])
		end
		hierarchy = truncated
	end

	return hierarchy
end

-- Create or find keyword hierarchy in Lightroom
-- Returns the leaf keyword object
local function createKeywordHierarchy(catalog, hierarchyArray)
	-- Validate inputs
	if not catalog then
		logger:errorf("createKeywordHierarchy: catalog is nil")
		return nil
	end
	
	if not hierarchyArray or #hierarchyArray == 0 then
		logger:tracef("createKeywordHierarchy: empty hierarchy array")
		return nil
	end
	
	local LrPrefs = import "LrPrefs"
	local localPrefs = LrPrefs.prefsForPlugin()
	local createFullHierarchy = localPrefs.createFullHierarchy ~= false

	local effectiveHierarchy = {}
	if hierarchyArray then
		if createFullHierarchy then
			for _, value in ipairs(hierarchyArray) do
				table.insert(effectiveHierarchy, value)
			end
		else
			-- Only use the leaf keyword when full hierarchy creation is disabled
			table.insert(effectiveHierarchy, hierarchyArray[#hierarchyArray])
		end
	end

	local LrTasks = import "LrTasks"
	local currentParent = nil
	local leafKeyword = nil
	
	-- Create keywords from root to leaf 
	-- IMPORTANT: According to Lightroom SDK, newly created keywords are not available
	-- for access until the withWriteAccessDo function returns. We cannot call getName()
	-- or other methods on them within the same write access.
	local success, result = LrTasks.pcall(function()
		for i, keywordName in ipairs(effectiveHierarchy) do
			if not keywordName or keywordName == "" then
				logger:errorf("createKeywordHierarchy: invalid keyword name at index %d", i)
				return nil
			end
			
			-- Clean the keyword name
			local cleanName = string.match(keywordName, "^%s*(.-)%s*$") -- trim whitespace
			if not cleanName or cleanName == "" then
				logger:errorf("createKeywordHierarchy: empty keyword name after cleaning at index %d", i)
				return nil
			end
			
			local keyword = catalog:createKeyword(cleanName, nil, true, currentParent, true)
			
			-- createKeyword returns false if keyword exists and returnExisting is false
			-- but we pass returnExisting as true, so it should return the existing keyword
			if keyword and keyword ~= false then
				-- Don't try to access the keyword object (like getName()) within write access
				-- Just verify it's a table and set it as parent for next iteration
				if type(keyword) == "table" then
					leafKeyword = keyword
					currentParent = keyword
				else
					logger:errorf("createKeyword returned invalid object: %s", tostring(keyword))
					return nil
				end
			else
				logger:errorf("Failed to create keyword: %s, result: %s", cleanName, tostring(keyword))
				return nil
			end
		end
		return leafKeyword
	end)
	
	if success then
		return result
	else
		logger:errorf("createKeywordHierarchy failed: %s", tostring(result))
		return nil
	end
end

-- Get full hierarchy path for a keyword (for display purposes)
local function getKeywordHierarchyPath(keyword)
	if not keyword then
		return ""
	end
	
	local LrPrefs = import "LrPrefs"
	local LrTasks = import "LrTasks"
	local prefs = LrPrefs.prefsForPlugin()
	local path = {}
	local current = keyword
	local separator = prefs.keywordHierarchySeparator or " > "
	
	-- Walk up the hierarchy - all keyword methods need async context
	local success, result = LrTasks.pcall(function()
		local pathArray = {}
		local currentKeyword = current
		while currentKeyword do
			table.insert(pathArray, 1, currentKeyword:getName()) -- Insert at beginning
			currentKeyword = currentKeyword:getParent()
		end
		return pathArray
	end)
	
	if success then
		path = result
	else
		logger:errorf("getKeywordHierarchyPath failed: %s", tostring(result))
		return ""
	end
	
	return table.concat(path, separator)
end

-- Check if a keyword string contains hierarchy separators
local function isHierarchicalKeyword(keywordString)
	if not keywordString then
		return false
	end
	local LrPrefs = import "LrPrefs"
	local prefs = LrPrefs.prefsForPlugin()
	local separator = prefs.keywordHierarchySeparator or " > "
	local isHierarchical = string.find(keywordString, separator, 1, true) ~= nil
	return isHierarchical
end

--------------------------------------------------------------------------------

-- Collection Management Functions

-- Create or get collection set for AI tagged photos
local function getOrCreateAICollectionSet()
	local catalog = LrApplication.activeCatalog()
	local collectionSet = nil
	
	-- Look for existing AI collection set
	local allCollections = catalog:getChildCollectionSets()
	for _, set in ipairs(allCollections) do
		if set:getName() == "AI Tagged" then
			collectionSet = set
			break
		end
	end
	
	-- Create if doesn't exist
	if not collectionSet then
		collectionSet = catalog:createCollectionSet("AI Tagged", nil, true)
		logger:info("Created AI collection set: AI Tagged")
	end
	
	return collectionSet
end

-- Create or get a collection within the AI collection set
local function getOrCreateCollection(name, parent)
	local catalog = LrApplication.activeCatalog()
	
	-- Look for existing collection
	local collections = parent:getChildCollections()
	for _, collection in ipairs(collections) do
		if collection:getName() == name then
			return collection
		end
	end
	
	-- Create new collection
	local collection = catalog:createCollection(name, parent, true)
	logger:infof("Created collection: %s", name)
	
	-- Force refresh to ensure collection info is available
	LrTasks.yield()
	
	return collection
end

-- Determine which collections a photo should belong to based on keywords (including hierarchical)
local function determinePhotoCollections(keywords, scheme)
	local collections = {}
	
	-- Helper function to extract searchable terms from keyword (hierarchical or flat)
	local function extractSearchableTerms(keyword)
		local LrPrefs = import "LrPrefs"
		local prefs = LrPrefs.prefsForPlugin()
		local terms = {}
		
		if prefs.useHierarchicalKeywords and isHierarchicalKeyword(keyword) then
			-- For hierarchical keywords, extract all levels for matching
			local hierarchy = parseKeywordHierarchy(keyword)
			for _, term in ipairs(hierarchy) do
				table.insert(terms, term)
			end
		else
			-- For flat keywords, just use the keyword itself
			table.insert(terms, keyword)
		end
		
		return terms
	end
	
	if scheme == "Content-Based" then
		for collectionName, collectionKeywords in pairs(KEYWORD_COLLECTIONS) do
			for _, keyword in ipairs(keywords) do
				local searchableTerms = extractSearchableTerms(keyword)
				
				for _, term in ipairs(searchableTerms) do
					for _, collectionKeyword in ipairs(collectionKeywords) do
						if string.lower(term):find(string.lower(collectionKeyword)) then
							table.insert(collections, collectionName)
							break
						end
					end
				end
			end
		end
	elseif scheme == "Location-Based" then
		for collectionName, collectionKeywords in pairs(LOCATION_COLLECTIONS) do
			for _, keyword in ipairs(keywords) do
				local searchableTerms = extractSearchableTerms(keyword)
				
				for _, term in ipairs(searchableTerms) do
					for _, collectionKeyword in ipairs(collectionKeywords) do
						if string.lower(term):find(string.lower(collectionKeyword)) then
							table.insert(collections, collectionName)
							break
						end
					end
				end
			end
		end
	end
	
	-- Remove duplicates
	local uniqueCollections = {}
	local seen = {}
	for _, collection in ipairs(collections) do
		if not seen[collection] then
			table.insert(uniqueCollections, collection)
			seen[collection] = true
		end
	end
	
	return uniqueCollections
end

-- Create auto collections for processed photos
local function createAutoCollections(processedPhotos)
	if not prefs.createAutoCollections then
		return
	end
	
	LrTasks.startAsyncTask(function()
		logger:info("Creating auto collections for AI tagged photos...")
		
		local catalog = LrApplication.activeCatalog()
		local aiCollectionSet = nil
		local schemeSet = nil
		local qualitySet = nil
			
		-- Step 1: Create collection sets first
		catalog:withWriteAccessDo("Create Collection Sets", function()
			aiCollectionSet = getOrCreateAICollectionSet()
			if prefs.createAutoCollections then
				local scheme = prefs.collectionScheme or "Content-Based"
				schemeSet = catalog:createCollectionSet(scheme, aiCollectionSet, true)
				qualitySet = catalog:createCollectionSet("Quality-Based", aiCollectionSet, true)
				logger:infof("Created collection sets: %s, Quality-Based", scheme)
			end
		end)
		
		-- Step 2: Create content-based collections
		if prefs.createAutoCollections and schemeSet then
			local scheme = prefs.collectionScheme or "Content-Based"
			
			-- Group photos by their determined collections
			local photoGroups = {}
			
			for _, photoData in ipairs(processedPhotos) do
				local keywords = {}
				if photoData.keywords then
					for _, keywordData in ipairs(photoData.keywords) do
						if keywordData.selected then
							table.insert(keywords, keywordData.title or keywordData.description)
						end
					end
				end
				
				local photoCollections = determinePhotoCollections(keywords, scheme)
				
				for _, collectionName in ipairs(photoCollections) do
					photoGroups[collectionName] = photoGroups[collectionName] or {}
					table.insert(photoGroups[collectionName], photoData.photo)
				end
			end
			
			-- Create collections and add photos in separate write access
			catalog:withWriteAccessDo("Create Content Collections", function()
				for collectionName, photos in pairs(photoGroups) do
					if #photos > 0 then
						local collection = catalog:createCollection(collectionName, schemeSet, true)
						collection:addPhotos(photos)
						logger:infof("Added %d photos to collection: %s", #photos, collectionName)
					end
				end
			end)
		end
		
		-- Step 3: Create quality-based collections
		if prefs.createAutoCollections and qualitySet then
			local highConfidence = {}
			local mediumConfidence = {}
			local lowConfidence = {}
			
			for _, photoData in ipairs(processedPhotos) do
				local confidence = photoData.confidence or 0.5
				
				if confidence >= 0.9 then
					table.insert(highConfidence, photoData.photo)
				elseif confidence >= 0.7 then
					table.insert(mediumConfidence, photoData.photo)
				else
					table.insert(lowConfidence, photoData.photo)
				end
			end
			
			-- Create quality collections in separate write access
			catalog:withWriteAccessDo("Create Quality Collections", function()
				if #highConfidence > 0 then
					local collection = catalog:createCollection("High Confidence (>90%)", qualitySet, true)
					collection:addPhotos(highConfidence)
					logger:infof("Added %d photos to High Confidence collection", #highConfidence)
				end
				
				if #mediumConfidence > 0 then
					local collection = catalog:createCollection("Medium Confidence (70-90%)", qualitySet, true)
					collection:addPhotos(mediumConfidence)
					logger:infof("Added %d photos to Medium Confidence collection", #mediumConfidence)
				end
				
				if #lowConfidence > 0 then
					local collection = catalog:createCollection("Needs Review (<70%)", qualitySet, true)
					collection:addPhotos(lowConfidence)
					logger:infof("Added %d photos to Needs Review collection", #lowConfidence)
				end
			end)
		end
		
		
		logger:info("Auto collections creation completed")
	end)
end

--------------------------------------------------------------------------------

-- save photo from propertyTable[ propXXX ] to propertyTable.photos[ i ]
local function savePhoto( propertyTable, index )
	-- Skip saving if index is 0 (no photo selected) or out of range
	if index <= 0 or index > #propertyTable[ propPhotos ] then
		logger:tracef( "savePhoto: skipping invalid index %d (valid range: 1-%d)", index, #propertyTable[ propPhotos ] )
		return
	end

	local photo = propertyTable[ propPhotos ][ index ]
	if photo ~= nil then
		local keywords = photo.keywords or { }
		-- Only update selected state for keywords within the UI display range
		-- Keywords beyond maxKeywords are not shown in the UI, so their
		-- property bindings were never set — preserve their original selected state
		local uiLimit = math.min( #keywords, prefs.maxKeywords )
		for i = 1, uiLimit do
			keywords[ i ].selected = propertyTable[ propKeywordSelected( i ) ]
		end

		-- Save all metadata fields
		photo.title = propertyTable[ propTitle ]
		photo.caption = propertyTable[ propCaption ]
		photo.headline = propertyTable[ propHeadline ]
		photo.instructions = propertyTable[ propInstructions ]
		photo.location = propertyTable[ propLocation ]
		photo.copyright = propertyTable[ propCopyright ]
	end
end

-- load photo from propertyTable.photos[ i ] to propertyTable[ propXXX ]
local function loadPhoto( propertyTable, index )
	-- Skip loading if index is invalid or out of range
	if index <= 0 or index > #propertyTable[ propPhotos ] then
		logger:errorf( "loadPhoto: invalid index %d (valid range: 1-%d)", index, #propertyTable[ propPhotos ] )
		return
	end

	local photo = propertyTable[ propPhotos ][ index ]
	if photo == nil then
		logger:errorf( "loadPhoto: photo at index %d is nil", index )
		return
	end

	local keywords = photo.keywords or { }
	for i = 1, prefs.maxKeywords do
		local keyword = keywords[ i ] or { description = nil, selected = false }
		local displayText = keyword.description
		propertyTable[ propKeywordTitle( i ) ] = displayText
		propertyTable[ propKeywordSelected( i ) ] = keyword.selected
	end

	-- Load all metadata fields
	propertyTable[ propTitle ] = photo.title or ""
	propertyTable[ propCaption ] = photo.caption or ""
	propertyTable[ propHeadline ] = photo.headline or ""
	propertyTable[ propInstructions ] = photo.instructions or ""
	propertyTable[ propLocation ] = photo.location or ""
	propertyTable[ propCopyright ] = photo.copyright or ""
end

-- select photo (i.e. move from index X to Y)
local function selectPhoto( propertyTable, newIndex )
	local oldIndex = propertyTable[ propCurrentPhotoIndex ]
	if oldIndex ~= newIndex then
		savePhoto( propertyTable, oldIndex )
	end

	if newIndex > 0 and newIndex <= #propertyTable[ propPhotos ] then
		loadPhoto( propertyTable, newIndex )
		propertyTable[ propCurrentPhotoIndex ] = newIndex
	else
		logger:errorf( "selectPhoto failed: index %d out of range (1-%d)", newIndex, #propertyTable[ propPhotos ] )
	end
end

local function applyDecorationToLeafName( leafName )
	if not leafName or leafName == "" then
		return leafName
	end

	if prefs.decorateKeyword == AiTaggerConstants.decorateKeywordPrefix and prefs.decorateKeywordValue and prefs.decorateKeywordValue ~= "" then
		return string.format( "%s %s", prefs.decorateKeywordValue, leafName )
	elseif prefs.decorateKeyword == AiTaggerConstants.decorateKeywordSuffix and prefs.decorateKeywordValue and prefs.decorateKeywordValue ~= "" then
		return string.format( "%s %s", leafName, prefs.decorateKeywordValue )
	end

	return leafName
end

local function buildKeywordMatchDescriptor(keywordString)
	if not keywordString or keywordString == "" then
		return nil
	end

	local localPrefs = prefs
	local separator = localPrefs.keywordHierarchySeparator or " > "

	if localPrefs.useHierarchicalKeywords and isHierarchicalKeyword(keywordString) and localPrefs.createFullHierarchy ~= false then
		return { type = "hierarchy", value = keywordString }
	end

	local leafName = keywordString
	if localPrefs.useHierarchicalKeywords and isHierarchicalKeyword(keywordString) then
		local hierarchy = parseKeywordHierarchy(keywordString)
		if #hierarchy > 0 then
			leafName = hierarchy[#hierarchy]
		end
	end

	if localPrefs.decorateKeyword == AiTaggerConstants.decorateKeywordParent and localPrefs.decorateKeywordValue and localPrefs.decorateKeywordValue ~= "" then
		return {
			type = "hierarchy",
			value = string.format( "%s%s%s", localPrefs.decorateKeywordValue, separator, leafName )
		}
	end

	return { type = "name", value = applyDecorationToLeafName( leafName ) }
end

local function keywordMatchesDescriptor(descriptor, keywordObj)
	if not descriptor or not keywordObj then
		return false
	end

	if descriptor.type == "hierarchy" then
		local path = getKeywordHierarchyPath(keywordObj)
		if not path or path == "" then
			return false
		end
		return string.lower(path) == string.lower(descriptor.value)
	elseif descriptor.type == "name" then
		local name = keywordObj:getName()
		if not name then
			return false
		end
		return string.lower(name) == string.lower(descriptor.value)
	end

	return false
end

local function removeDeselectedKeywords(photo, keywordData)
	if not keywordData or #keywordData == 0 then
		return
	end

	local existingKeywords = photo:getRawMetadata( "keywords" ) or {}
	if #existingKeywords == 0 then
		return
	end

	for _, keyword in ipairs( keywordData ) do
		if keyword and not keyword.selected and keyword.description and keyword.description ~= "" then
			local descriptor = buildKeywordMatchDescriptor( keyword.description )
			if descriptor then
				for _, keywordObj in ipairs( existingKeywords ) do
					if keywordMatchesDescriptor( descriptor, keywordObj ) then
						local LrTasks = import "LrTasks"
						local success, err = LrTasks.pcall(function()
							photo:removeKeyword( keywordObj )
						end)
						if not success then
							logger:errorf("Failed to remove keyword %s: %s", keyword.description, tostring(err))
						end
						break
					end
				end
			end
		end
	end
end

-- apply the selected keywords and all metadata to the photo
local function applyMetadataToPhoto( photo, keywords, title, caption, headline, instructions, location, copyrightNotice, confidence )
	-- Helper function to safely set metadata
	local function safeSetMetadata( fieldName, value, description )
		local success, error = pcall( function()
			photo:setRawMetadata( fieldName, value )
		end )
		if success then
		else
			logger:errorf( "failed to set %s (%s): %s", description, fieldName, tostring(error) )
		end
		return success
	end

	local catalog = photo.catalog
	catalog:withWriteAccessDo(
		LOC( "$$$/AiTagger/ActionName=Apply Metadata " ),
		function()
			local function createDecoratedKeyword( keywordString, decoration, value )
				-- Validate inputs
				if not keywordString or keywordString == "" then
					logger:errorf("createDecoratedKeyword: invalid keywordString")
					return nil
				end

				local LrPrefs = import "LrPrefs"
				if not LrPrefs then
					logger:errorf("createDecoratedKeyword: failed to import LrPrefs")
					return nil
				end

				local localPrefs = LrPrefs.prefsForPlugin()
				if not localPrefs then
					logger:errorf("createDecoratedKeyword: failed to get plugin preferences")
					return nil
				end

				-- Check if hierarchical keywords are enabled and the keyword contains hierarchy
				if localPrefs.useHierarchicalKeywords then

					local isHierarchical = isHierarchicalKeyword(keywordString)

					if isHierarchical then
						local hierarchy = parseKeywordHierarchy(keywordString)

						if #hierarchy > 0 then
							-- For hierarchical keywords, create the full hierarchy
							local leafKeyword = createKeywordHierarchy(catalog, hierarchy)
							if leafKeyword then
								return leafKeyword
							else
								logger:errorf("Failed to create hierarchical keyword: %s, falling back to flat", keywordString)
								-- Fall back to flat keyword creation
							end
						end
					end
				end
				
				-- Original flat keyword creation logic (fallback or when hierarchical is disabled)
				local name = keywordString
				local parent = nil
				
				-- Handle legacy decoration options
				if decoration == AiTaggerConstants.decorateKeywordParent then
					parent = catalog:createKeyword( value, nil, true, nil, true )
					if parent == nil then
						logger:errorf( "failed to add parent keyword %s", value )
						return nil
					end
				end
				if decoration == AiTaggerConstants.decorateKeywordPrefix then
					name = string.format( "%s %s", value, name )
				elseif decoration == AiTaggerConstants.decorateKeywordSuffix then
					name = string.format( "%s %s", name, value )
				else
					 -- AiTaggerConstants.decorateKeywordAsIs or decorateKeywordParent, do nothing
				end
				
				-- For hierarchical keywords that failed hierarchy creation, use just the leaf name
				if localPrefs.useHierarchicalKeywords and isHierarchicalKeyword(keywordString) then
					local hierarchy = parseKeywordHierarchy(keywordString)
					if #hierarchy > 0 then
						name = hierarchy[#hierarchy] -- Use leaf keyword name only
					end
				end
				
				-- Final validation before creating keyword
				if not name or name == "" then
					logger:errorf("createDecoratedKeyword: final name is invalid")
					return nil
				end
				
				
				local LrTasks = import "LrTasks"
				local success, keyword = LrTasks.pcall(function()
					return catalog:createKeyword( name, nil, true, parent, true )
				end)
				
				if success and keyword then
					return keyword
				else
					logger:errorf("Failed to create flat keyword: %s (error: %s)", name, tostring(keyword))
					return nil
				end
			end

			-- Apply keywords to Lightroom Keywords
			local selectedKeywords = {}
			removeDeselectedKeywords(photo, keywords)

			for i, keyword in ipairs( keywords ) do
				if not keyword then
					logger:errorf("Keyword at index %d is nil", i)
				elseif keyword.selected then

					if keyword.description then
						-- Add to Lightroom Keywords
						local keywordObj = createDecoratedKeyword( keyword.description, prefs.decorateKeyword, prefs.decorateKeywordValue )
						if keywordObj then
							local LrTasks = import "LrTasks"
							local success, err = LrTasks.pcall(function()
								photo:addKeyword( keywordObj )
							end)
							if success then
								-- Collect for IPTC Keywords (use original description, not decorated)
								table.insert( selectedKeywords, keyword.description )
							else
								logger:errorf("Failed to add keyword to photo: %s (error: %s)", keyword.description, tostring(err))
							end
						else
							logger:errorf( "failed to create keyword object for %s", keyword.description )
						end
					else
						logger:errorf("Keyword has no description at index %d", i)
					end
				end
			end

			-- Save keywords to IPTC Keywords field as well
			if prefs.saveKeywordsToIptc and #selectedKeywords > 0 then
				-- Note: Lightroom doesn't expose a direct IPTC keywords field via setRawMetadata
				-- Keywords are automatically included in IPTC when exporting if they're in Lightroom Keywords
				-- This is a limitation of the Lightroom SDK
				logger:infof( "IPTC keywords: %d keywords selected", #selectedKeywords )
			end

			-- Apply IPTC metadata using correct Lightroom field names
			logger:tracef( "IPTC preferences: title=%s, caption=%s, headline=%s, instructions=%s, copyright=%s, location=%s",
				tostring(prefs.saveTitleToIptc), tostring(prefs.saveCaptionToIptc), tostring(prefs.saveHeadlineToIptc),
				tostring(prefs.saveInstructionsToIptc), tostring(prefs.saveCopyrightToIptc),
				tostring(prefs.saveLocationToIptc) )

			if prefs.saveTitleToIptc and title and title ~= "" then
				safeSetMetadata( "title", title, "IPTC title" )
			else
				logger:tracef( "skipping IPTC title: enabled=%s, title='%s'", tostring(prefs.saveTitleToIptc), title or "nil" )
			end

			if prefs.saveCaptionToIptc and caption and caption ~= "" then
				safeSetMetadata( "caption", caption, "IPTC caption" )
			else
				logger:tracef( "skipping IPTC caption: enabled=%s, caption='%s'", tostring(prefs.saveCaptionToIptc), caption or "nil" )
			end

			if prefs.saveHeadlineToIptc and headline and headline ~= "" then
				safeSetMetadata( "headline", headline, "IPTC headline" )
			else
				logger:tracef( "skipping IPTC headline: enabled=%s, headline='%s'", tostring(prefs.saveHeadlineToIptc), headline or "nil" )
			end

			if prefs.addAiTaggerMarker == true then
				local provider = AIProviderFactory.getCurrentProvider()
				local model
				if provider == "gemini" then
					model = prefs.geminiModel or "gemini-2.5-flash"
				elseif provider == "ollama" then
					model = prefs.ollamaModel or ""
				elseif provider == "openai" then
					model = prefs.openaiModel or "gpt-4o"
				else
					model = ""
				end
				local marker = "AiTagger: " .. provider .. (model ~= "" and (" " .. model) or "")
				safeSetMetadata( "instructions", marker, "IPTC instructions marker" )
			elseif prefs.saveInstructionsToIptc and instructions and instructions ~= "" then
				safeSetMetadata( "instructions", instructions, "IPTC instructions" )
			end

			if prefs.saveCopyrightToIptc and copyrightNotice and copyrightNotice ~= "" then
				safeSetMetadata( "copyright", copyrightNotice, "IPTC copyright" )
				safeSetMetadata( "rightsUsageTerms", copyrightNotice, "IPTC rights usage terms" )
			end

			if prefs.saveLocationToIptc and location and location ~= "" then
				-- Try different location fields that are known to work in Lightroom
				safeSetMetadata( "location", location, "IPTC location" )
				safeSetMetadata( "city", location, "IPTC city" )
			end
			
			-- Categories are already added as keywords via applyMetadataToPhoto
		end,
		{ timeout = 5 }
	)
end

-- Export analysis results to CSV
local function exportResults( propertyTable )
	local photos = propertyTable[ propPhotos ]
	if not photos or #photos == 0 then
		LrDialogs.message( LOC( "$$$/AiTagger/Export/NoResults=No Results" ), LOC( "$$$/AiTagger/Export/NoResultsMessage=No analysis results to export." ), "info" )
		return
	end

	local fileName = LrDialogs.runSavePanel( {
		title = LOC( "$$$/AiTagger/Export/Title=Export Analysis Results" ),
		label = LOC( "$$$/AiTagger/Export/SaveAs=Save as:" ),
		requiredFileType = "csv",
		initialDirectory = LrPathUtils.getStandardFilePath( "desktop" ),
		initialFileName = "aiimagetagger_results_" .. LrDate.timeToUserFormat( LrDate.currentTime(), "%Y%m%d_%H%M%S" ) .. ".csv"
	} )

	if fileName then
		local file = io.open( fileName, "w" )
		if file then
			local writeSuccess, writeErr = pcall( function()
				-- Write CSV header
				file:write( LOC( "$$$/AiTagger/Export/CSVHeader=Filename,Title,Caption,Headline,Keywords,Instructions,Copyright,Location,Analysis Time (sec)" ) .. "\n" )

				-- Write data for each photo
				for _, photoData in ipairs( photos ) do
					local photo = photoData.photo
					local filename = photo:getFormattedMetadata( "fileName" ) or ""
					local title = (photoData.title or ""):gsub( '"', '""' ) -- Escape quotes
					local caption = (photoData.caption or ""):gsub( '"', '""' )
					local headline = (photoData.headline or ""):gsub( '"', '""' )
					local instructions = (photoData.instructions or ""):gsub( '"', '""' )
					local copyright = (photoData.copyright or ""):gsub( '"', '""' )
					local location = (photoData.location or ""):gsub( '"', '""' )
					local elapsed = photoData.elapsed or 0

					-- Collect selected keywords (preserve hierarchical format)
					local keywords = {}
					if photoData.keywords then
						for _, keyword in ipairs( photoData.keywords ) do
							if keyword.selected then
								-- Keep hierarchical keywords in their full form for export
								table.insert( keywords, keyword.description )
							end
						end
					end
					local keywordStr = table.concat( keywords, "; " ):gsub( '"', '""' )

					file:write( string.format( '"%s","%s","%s","%s","%s","%s","%s","%s",%.3f\n',
						filename, title, caption, headline, keywordStr, instructions, copyright, location, elapsed ) )
				end
			end )

			file:close()

			if writeSuccess then
				LrDialogs.message( LOC( "$$$/AiTagger/Export/Complete=Export Complete" ), LOC( "$$$/AiTagger/Export/CompleteMessage=Analysis results exported to:\n" ) .. fileName, "info" )
			else
				logger:errorf( "CSV export write error: %s", tostring( writeErr ) )
				LrDialogs.message( LOC( "$$$/AiTagger/Export/Failed=Export Failed" ), LOC( "$$$/AiTagger/Export/FailedMessage=Could not create file:\n" ) .. fileName, "error" )
			end
		else
			LrDialogs.message( LOC( "$$$/AiTagger/Export/Failed=Export Failed" ), LOC( "$$$/AiTagger/Export/FailedMessage=Could not create file:\n" ) .. fileName, "error" )
		end
	end
end

local function showResponse( propertyTable )

	local f = LrView.osFactory()

	-- create keywords array
	local keywords = { }
	for i = 1, prefs.maxKeywords do
		local propTitle = propKeywordTitle( i )
		local propSelected = propKeywordSelected( i )
		table.insert( keywords,
			f:row {
				f:checkbox {
					visible = LrBinding.keyIsNotNil( propTitle ),
					title = bind { 
						key = propTitle,
						transform = function( value, fromTable )
							-- Display hierarchical keywords with visual formatting
							if value then
								local LrPrefs = import "LrPrefs"
								local localPrefs = LrPrefs.prefsForPlugin()
								if localPrefs.useHierarchicalKeywords and isHierarchicalKeyword(value) then
									-- Keep the full hierarchy for display
									return value
								end
							end
							return value
						end,
					},
					value = bind { key = propSelected },
					width = 400, -- Increased width to accommodate hierarchical keywords
					tooltip = bind { 
						key = propTitle,
						transform = function( value, fromTable )
							-- Show hierarchy explanation in tooltip
							if value then
								local LrPrefs = import "LrPrefs"
								local localPrefs = LrPrefs.prefsForPlugin()
								if localPrefs.useHierarchicalKeywords and isHierarchicalKeyword(value) then
									local hierarchy = parseKeywordHierarchy(value)
									if #hierarchy > 1 then
										return string.format("Hierarchical keyword: %s", table.concat(hierarchy, " → "))
									end
								end
							end
							return nil
						end,
					},
				},
			}
		)
	end



	propertyTable:addObserver( propPhotos,
		function( propertyTable, key, value )
			if #value > 0 and propertyTable[ propCurrentPhotoIndex ] == 0 then
				selectPhoto( propertyTable, 1 )
			end
		end
	)

	propertyTable:addObserver( propCurrentPhotoIndex,
		function( propertyTable, key, value )
			LrTasks.startAsyncTask(
				function()
					local entry = propertyTable[ propPhotos ][ value ]
					if entry and entry.photo then
						propertyTable[ propCurrentPhotoName ] = entry.photo:getFormattedMetadata( "fileName" )
					end
				end
			)
		end
	)

	local contents = f:column {
		bind_to_object = propertyTable,
		spacing = f:dialog_spacing(),
		fill_horizontal = 1,
		place_horizontal = 0.5,
		width = 900,
		f:column {
			fill_horizontal = 1,
			place_horizontal = 0.5,
			f:row {
				f:push_button {
					title = LOC( "$$$/AiTagger/PrevPhoto=^U+25C0" ),
					fill_horizontal = 0.25,
					place_vertical = 0.5,
					enabled = bind {
						key = propCurrentPhotoIndex,
						transform = function( value, fromTable )
							local hasPrev = (value or 0) > 1
							return hasPrev
						end,
					},
					action = function( btn )
						local currentIndex = propertyTable[ propCurrentPhotoIndex ]
						local newIndex = currentIndex - 1
						selectPhoto( propertyTable, newIndex )
					end,
				},
				f:catalog_photo {
					visible = LrBinding.keyIsNot( propCurrentPhotoIndex, 0 ),
					photo = bind {
						key = propCurrentPhotoIndex,
						transform = function( value, fromTable )
							if value > 0 then
								local entry = propertyTable[ propPhotos ][ value ]
								return entry and entry.photo or nil
							end
							return nil
						end,
					},
					width = 400,
					height = 300,
					fill_horizontal = 0.5,
					place_horizontal = 0.5,
					frame_width = 0,
					frame_color = LrColor(), -- alpha = 0
					background_color = LrColor(), -- alpha = 0
				},
				f:push_button {
					title = LOC( "$$$/AiTagger/NextPhoto=^U+25B6" ),
					fill_horizontal = 0.25,
					place_vertical = 0.5,
					enabled = bind {
						keys = { propCurrentPhotoIndex, propPhotos },
						operation = function( binder, values, fromTable )
							local i = values[ propCurrentPhotoIndex ] or 0
							local photos = values[ propPhotos ] or {}
							local hasNext = photos[ i + 1 ] ~= nil
							return hasNext
						end,
					},
					action = function( btn )
						local currentIndex = propertyTable[ propCurrentPhotoIndex ]
						local newIndex = currentIndex + 1
						logger:tracef( "next photo: current=%d, new=%d, total=%d", currentIndex, newIndex, #propertyTable[ propPhotos ] )
						selectPhoto( propertyTable, newIndex )
					end,
				},
			},
			f:static_text {
				visible = LrBinding.keyIsNot( propCurrentPhotoIndex, 0 ),
				title = bind {
					keys = { propCurrentPhotoIndex, propCurrentPhotoName, propPhotos },
					operation = function( binder, values, fromTable )
						local idx = values[ propCurrentPhotoIndex ]
						local entry = values[ propPhotos ][ idx ]
						local elapsed = entry and entry.elapsed or 0
						return LOC( "$$$/AiTagger/PhotoXofY=Photo ^1 of ^2: ^3 (^4 sec)",
							LrStringUtils.numberToStringWithSeparators( idx, 0 ),
							LrStringUtils.numberToStringWithSeparators( #values[ propPhotos ], 0 ),
							values[ propCurrentPhotoName ],
							LrStringUtils.numberToStringWithSeparators( elapsed, 2 ) )
					end,
				},
				fill_horizontal = 1,
				alignment = "center"
			},
			f:static_text {
				title = bind {
					key = propPhotos,
					transform = function( value, fromTable )
						local numPhotos = #value
						local remPhotos = propertyTable[ propTotalPhotos ] - numPhotos
						local consumedTime = propertyTable[ propConsumedTime ]
						local elapsedTime = propertyTable[ propElapsedTime ]
						if remPhotos > 0 then
							if #value > 0 then
								-- use elapsedTime rather than consumedTime to factor in parallelization
								local remTime = math.ceil( elapsedTime / numPhotos * remPhotos )
								return LOC( "$$$/AiTagger/PhotosRemaining=^1 photos to analyze, estimated completion in ^2 sec (^3 sec elapsed)",
									LrStringUtils.numberToStringWithSeparators( remPhotos, 0 ),
									LrStringUtils.numberToStringWithSeparators( remTime, 0 ),
									LrStringUtils.numberToStringWithSeparators( elapsedTime, 2 ) )
							else
								return LOC( "$$$/AiTagger/PhotosRemaining=^1 photos to analyze",
									LrStringUtils.numberToStringWithSeparators( remPhotos, 0 ) )
							end
						else
							return LOC( "$$$/AiTagger/PhotosRemaining=^1 photos analyzed in ^2 sec (^3 sec elapsed)",
								LrStringUtils.numberToStringWithSeparators( numPhotos, 0 ),
								LrStringUtils.numberToStringWithSeparators( consumedTime, 2 ),
								LrStringUtils.numberToStringWithSeparators( elapsedTime, 2 ) )
						end
					end,
				},
				fill_horizontal = 1,
				alignment = "center"
			},
		},
		f:scrolled_view {
			fill_horizontal = 1,
			fill_vertical = 1,
			width = 900,
			f:row {
				f:column {
					fill_horizontal = 0.5,
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogTitleTitle=Title" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propTitle },
							fill_horizontal = 1,
							height_in_lines = 1,
							width = 410,
						},
					},
					f:spacer { height = 8 },
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogKeywordsTitle=Keywords" ),
						font = "<system/bold>",
						f:row {
							place = "overlapping",
							f:column {
								f:static_text {
									visible = LrBinding.keyIsNil( propKeywordTitle( 1 ) ),
									title = LOC( "$$$/AiTagger/NoKeywords=None" ),
									fill_horizontal = 1,
								},
							},
							f:column( keywords ),
						},
						f:row {
							visible = LrBinding.keyIsNotNil( propKeywordTitle( 1 ) ),
							f:push_button {
								title = LOC( "$$$/AiTagger/SelectAllKeywords=Select All" ),
								action = function()
									for i = 1, prefs.maxKeywords do
										if propertyTable[ propKeywordTitle( i ) ] then
											propertyTable[ propKeywordSelected( i ) ] = true
										end
									end
								end,
							},
							f:push_button {
								title = LOC( "$$$/AiTagger/DeselectAllKeywords=Deselect All" ),
								action = function()
									for i = 1, prefs.maxKeywords do
										if propertyTable[ propKeywordTitle( i ) ] then
											propertyTable[ propKeywordSelected( i ) ] = false
										end
									end
								end,
							},
						},
					},
				},
				f:spacer { width = 8 },
				f:column {
					fill_horizontal = 0.5,
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogCaptionTitle=Caption" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propCaption },
							fill_horizontal = 1,
							height_in_lines = 2,
							width = 410,
						},
					},
					f:spacer { height = 8 },
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogHeadlineTitle=Headline" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propHeadline },
							fill_horizontal = 1,
							height_in_lines = 4,
							width = 410,
						},
					},
					f:spacer { height = 8 },
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogInstructionsTitle=Instructions" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propInstructions },
							fill_horizontal = 1,
							height_in_lines = 3,
							width = 410,
						},
					},
					f:spacer { height = 8 },
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogCopyrightTitle=Copyright" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propCopyright },
							fill_horizontal = 1,
							height_in_lines = 2,
							width = 410,
						},
					},
					f:spacer { height = 8 },
					f:group_box {
						title = LOC( "$$$/AiTagger/ResultsDialogLocationTitle=Location" ),
						font = "<system/bold>",
						f:edit_field {
							value = bind { key = propLocation },
							fill_horizontal = 1,
							height_in_lines = 2,
							width = 410,
						},
					},
				},
			},
		},
		f:row {
			fill_horizontal = 1,
			f:push_button {
				enabled = LrBinding.keyIsNot( propCurrentPhotoIndex, 0 ),
				title = LOC( "$$$/AiTagger/ResultsDialogApply=Apply" ),
				place_horizontal = 1,
				action = function()
					LrTasks.startAsyncTask(
						function()
							savePhoto( propertyTable, propertyTable[ propCurrentPhotoIndex ])
							local photo = propertyTable[ propPhotos ][ propertyTable[ propCurrentPhotoIndex ] ]
							applyMetadataToPhoto( photo.photo, photo.keywords, photo.title, photo.caption, photo.headline, photo.instructions, photo.location, photo.copyright, photo.confidence )
						end
					)
				end,
			},
			f:push_button {
				enabled = LrBinding.keyIsNot( propCurrentPhotoIndex, 0 ),
				title = LOC( "$$$/AiTagger/ResultsDialogExport=Export Results" ),
				place_horizontal = 1,
				action = function()
					LrTasks.startAsyncTask(
						function()
							savePhoto( propertyTable, propertyTable[ propCurrentPhotoIndex ])
							exportResults( propertyTable )
						end
					)
				end,
			}
		},
	}
	local currentProvider = AIProviderFactory.getCurrentProvider()
	local results = LrDialogs.presentModalDialog {
		title = LOC( "$$$/AiTagger/ResultsDialogTitle=AI Tagger: " ) .. string.upper(string.sub(currentProvider, 1, 1)) .. string.sub(currentProvider, 2) .. LOC( "$$$/AiTagger/ResultsDialogTitleSuffix= Results" ),
		resizable = true,
		contents = contents,
		cancelVerb = LOC( "$$$/AiTagger/ResultsDialogCancel=Cancel" ),
		actionVerb = LOC( "$$$/AiTagger/ResultsDialogApplyAll=Apply All" ),
	}
	
	-- Handle the dialog result
	if results == "ok" then
		-- User clicked "Apply All" button (the default action)
		LrTasks.startAsyncTask(
			function()
				savePhoto( propertyTable, propertyTable[ propCurrentPhotoIndex ])
				for _, photo in ipairs( propertyTable[ propPhotos ] ) do
					applyMetadataToPhoto( photo.photo, photo.keywords, photo.title, photo.caption, photo.headline, photo.instructions, photo.location, photo.copyright, photo.confidence )
				end
				
				-- Create auto collections after applying all metadata (in separate task to avoid write access conflicts)
				LrTasks.startAsyncTask(function()
					LrTasks.sleep(0.5) -- Small delay to ensure all metadata writes are complete
					createAutoCollections( propertyTable[ propPhotos ] )
				end)
			end
		)
	end
end

local function AiTagger()
	LrFunctionContext.postAsyncTaskWithContext( "analyzing photos",
		function( context )
			LrDialogs.attachErrorDialogToFunctionContext( context )
			local catalog = LrApplication.activeCatalog()

			-- Check AI provider configuration
			local connectionTest = AIProviderFactory.testConnection()
			if not connectionTest.status then
				local provider = AIProviderFactory.getCurrentProvider()
				logger:errorf( "AI provider connection failed: %s", connectionTest.message )
				
				-- Customize error message based on the specific failure
				local errorMsg
				local testMessage = connectionTest.message or "Unknown error"
				if string.find(testMessage, "Rate limit") then
					errorMsg = string.format("OpenAI rate limit exceeded.\n\n%s\n\nThis is normal for new accounts. Please wait a minute and try again.\n\nCheck your usage and billing at: https://platform.openai.com/usage", testMessage)
				elseif string.find(testMessage, "API key") then
					errorMsg = string.format("AI provider (%s) not configured.\n\n%s\n\nPlease check plugin settings.", provider, testMessage)
				else
					errorMsg = string.format("AI provider (%s) connection failed.\n\n%s\n\nPlease check your internet connection and provider settings.", provider, testMessage)
				end
				
				LrDialogs.message( LOC( "$$$/AiTagger/AuthFailed=AI Provider Connection Error" ), errorMsg, "critical" )
			else
				local propertyTable = LrBinding.makePropertyTable( context )
				local photos = catalog:getTargetPhotos()
				logger:infof( "Selected %d photos from catalog", #photos )

				propertyTable[ propPhotos ] = { }
				propertyTable[ propCurrentPhotoIndex ] = 0
				propertyTable[ propTotalPhotos ] = #photos
				propertyTable[ propStartTime ] = LrDate.currentTime()
				propertyTable[ propElapsedTime ] = 0 -- elapsed wall time
				propertyTable[ propConsumedTime ] = 0 -- consumed CPU time
				propertyTable[ propTitle ] = ""
				propertyTable[ propCaption ] = ""
				propertyTable[ propHeadline ] = ""
				propertyTable[ propInstructions ] = ""
				propertyTable[ propLocation ] = ""
				propertyTable[ propCopyright ] = ""

				local progressScope = LrProgressScope {
					title = LOC( "$$$/AiTagger/ProgressScopeTitle=Analyzing Photos" ),
					functionContext = context
				}
				progressScope:setCancelable( true )

				-- First phase: Collect all thumbnails
				local thumbnailData = { } -- Store thumbnail data for processing
				local processingErrors = { } -- Collect errors instead of showing modal dialogs
				local thumbnailsPending = #photos
				logger:tracef( "begin collecting %d thumbnails", #photos )

				-- Set initial progress message
				progressScope:setCaption( LOC( "$$$/AiTagger/ProgressStarting=Collecting thumbnails for ^1 photos...", #photos ) )
				progressScope:setPortionComplete( 0, #photos )
				
				-- Recursive thumbnail request with progressive size fallback
				local MAX_THUMBNAIL_SIZE = 1048576 -- 1 MB
				local fallbackSizes = { {w=400, h=400}, {w=200, h=200}, {w=100, h=100} }

				local function requestThumbnailWithFallback(photo, fileName, fileExtension, photoIndex, sizes, sizeIndex)
					if sizeIndex > #sizes then
						-- All sizes exhausted
						logger:errorf( "All thumbnail sizes failed for %s", fileName )
						table.insert( processingErrors, {
							fileName = fileName,
							message = string.format( "Thumbnail generation failed at all sizes. This %s file may be problematic.", string.upper(fileExtension) ),
							type = "thumbnail"
						})
						thumbnailsPending = thumbnailsPending - 1
						return
					end

					local size = sizes[sizeIndex]
					photo:requestJpegThumbnail( size.w, size.h,
						function( jpegData, errorMsg )
							if jpegData then
								local jpegSize = string.len(jpegData)
								logger:infof( "%dx%d thumbnail generated for %s (size: %d bytes)", size.w, size.h, fileName, jpegSize )

								if jpegSize <= MAX_THUMBNAIL_SIZE then
									table.insert( thumbnailData, {
										photo = photo,
										jpegData = jpegData,
										fileName = fileName,
										index = photoIndex
									})
									thumbnailsPending = thumbnailsPending - 1
									return
								end

								logger:warnf( "%dx%d thumbnail for %s too large (%d bytes), trying smaller", size.w, size.h, fileName, jpegSize )
							else
								logger:errorf( "%dx%d thumbnail failed for %s: %s", size.w, size.h, fileName, errorMsg or "unknown error" )
							end

							-- Try next smaller size
							requestThumbnailWithFallback(photo, fileName, fileExtension, photoIndex, sizes, sizeIndex + 1)
						end
					)
				end

				-- Process thumbnails in batches to avoid overwhelming Lightroom's async thumbnail system
				local THUMBNAIL_BATCH_SIZE = 10
				local totalPhotos = #photos

				for batchStart = 1, totalPhotos, THUMBNAIL_BATCH_SIZE do
					if progressScope:isCanceled() or progressScope:isDone() then
						break
					end

					local batchEnd = math.min(batchStart + THUMBNAIL_BATCH_SIZE - 1, totalPhotos)
					local expectedPendingAfterBatch = totalPhotos - batchEnd
					logger:tracef( "Requesting thumbnails batch %d-%d of %d", batchStart, batchEnd, totalPhotos )

					for i = batchStart, batchEnd do
						if progressScope:isCanceled() or progressScope:isDone() then
							break
						end

						local photo = photos[i]
						local fileName = photo:getFormattedMetadata( "fileName" )
						progressScope:setCaption( LOC( "$$$/AiTagger/ProgressCaption=Preparing ^1 (^2 of ^3)", fileName, i, totalPhotos ) )
						progressScope:setPortionComplete( (i-1), totalPhotos )

						local fileExtension = string.lower(string.match(fileName, "%.([^%.]+)$") or "")
						local isRAW = (fileExtension == "nef" or fileExtension == "cr2" or fileExtension == "arw" or fileExtension == "dng" or fileExtension == "raf")
						local isTIFF = (fileExtension == "tif" or fileExtension == "tiff")
						local isLargeFile = isRAW or isTIFF

						-- Build size list: initial size + fallbacks
						local rawResolution = math.max(400, math.floor(prefs.thumbnailResolution / 2))
						local initialWidth = isLargeFile and rawResolution or prefs.thumbnailWidth
						local initialHeight = isLargeFile and rawResolution or prefs.thumbnailHeight
						local sizes = { {w=initialWidth, h=initialHeight} }
						for _, fb in ipairs(fallbackSizes) do
							if fb.w < initialWidth then
								table.insert(sizes, fb)
							end
						end

						logger:infof( "Requesting thumbnail for %s (%dx%d) - RAW: %s, TIFF: %s", fileName, initialWidth, initialHeight, tostring(isRAW), tostring(isTIFF) )

						requestThumbnailWithFallback(photo, fileName, fileExtension, i, sizes, 1)
					end

					-- Wait for this batch's thumbnails to complete before starting next batch
					local batchWaitCount = 0
					while thumbnailsPending > expectedPendingAfterBatch and not (progressScope:isCanceled() or progressScope:isDone()) do
						LrTasks.sleep( 0.1 )
						batchWaitCount = batchWaitCount + 1
						if batchWaitCount % 50 == 0 then -- Log every 5 seconds
							logger:warnf( "Still waiting for %d thumbnails in batch %d-%d after %.1f seconds",
								thumbnailsPending - expectedPendingAfterBatch, batchStart, batchEnd, batchWaitCount * 0.1 )
						end
						if batchWaitCount > 300 then -- 30 second timeout per batch
							logger:errorf( "Batch %d-%d timed out! %d thumbnails still pending in batch. Proceeding with next batch.",
								batchStart, batchEnd, thumbnailsPending - expectedPendingAfterBatch )
							break
						end
					end
					logger:tracef( "Batch %d-%d complete, %d thumbnails collected so far", batchStart, batchEnd, #thumbnailData )
				end

				-- Final safety wait for any remaining thumbnails
				if thumbnailsPending > 0 and not (progressScope:isCanceled() or progressScope:isDone()) then
					logger:warnf( "Final wait: %d thumbnails still pending after all batches", thumbnailsPending )
					local waitCount = 0
					while thumbnailsPending > 0 and not (progressScope:isCanceled() or progressScope:isDone()) do
						LrTasks.sleep( 0.1 )
						waitCount = waitCount + 1
						if waitCount > 100 then -- 10 second final timeout
							logger:errorf( "Final thumbnail collection timed out! %d thumbnails still pending. Proceeding with %d collected.",
								thumbnailsPending, #thumbnailData )
							break
						end
					end
				end

				logger:infof( "Thumbnail collection complete: %d of %d photos collected", #thumbnailData, totalPhotos )

				-- Second phase: Process thumbnails with AI analysis
				local runningTasks = 0
				local totalThumbnails = #thumbnailData
				local completedResults = {}
				logger:tracef( "begin analyzing %d thumbnails", totalThumbnails )

				progressScope:setCaption( LOC( "$$$/AiTagger/ProgressStarting=Starting AI analysis of ^1 photos...", totalThumbnails ) )
				progressScope:setPortionComplete( 0, totalThumbnails )
				
				for i, thumbnailInfo in ipairs( thumbnailData ) do
					if progressScope:isCanceled() or progressScope:isDone() then
						break
					end

					local photo = thumbnailInfo.photo
					local jpegData = thumbnailInfo.jpegData
					local fileName = thumbnailInfo.fileName
					local originalIndex = thumbnailInfo.index

					local function trace( msg, ... )
						logger:tracef( "[%d | %d | %s] %s", totalThumbnails, i, fileName, string.format( msg, ... ) )
					end

					while ( runningTasks >= prefs.maxTasks ) and not ( progressScope:isCanceled() or progressScope:isDone() ) do
						LrTasks.sleep( 0.2 )
					end
					runningTasks = runningTasks + 1

					-- Add delay between starting tasks to avoid overwhelming API with simultaneous requests
					-- Skip delay for first task to start processing immediately
					if i > 1 then
						local delaySeconds = (prefs.delayBetweenRequests or 1000) / 1000
						logger:tracef( "[%d | %d | %s] Delaying %.2f seconds before starting task", totalThumbnails, i, fileName, delaySeconds )
						LrTasks.sleep( delaySeconds )
					end

					-- Process in async task context where yielding is allowed
					LrTasks.startAsyncTask(
						function()
							LrFunctionContext.callWithContext( "aiAnalysis", function( context )
								trace( "analyzing thumbnail (%s bytes)", LrStringUtils.numberToStringWithSeparators( #jpegData, 0 ) )

								-- Update progress to show AI analysis in progress
								if not (progressScope:isCanceled() or progressScope:isDone()) then
									progressScope:setCaption( LOC( "$$$/AiTagger/ProgressAnalyzing=Analyzing with AI: ^1 (^2 of ^3)", fileName, i, totalThumbnails ) )
								end

								local start = LrDate.currentTime()
								local result = AIProviderFactory.analyze( fileName, jpegData, photo )
								local elapsed = LrDate.currentTime() - start
										if result.status then
											-- Clean keywords if hierarchical keywords are disabled
											if not prefs.useHierarchicalKeywords and result.keywords then
												local cleanedKeywords = {}
												local seen = {}
												for _, kwObj in ipairs(result.keywords) do
													local kw = kwObj.description
													-- Split hierarchical keywords if present (even if disabled, AI might return them)
													local parts = parseKeywordHierarchy(kw)
													
													for _, part in ipairs(parts) do
														-- Strip "AI: " prefix (case insensitive)
														local cleanKw = part:gsub("^[Aa][Ii]:%s*", "")
														
														if cleanKw ~= "" and not seen[cleanKw] then
															-- Create new keyword object for each part
															local newKwObj = { description = cleanKw, selected = kwObj.selected }
															table.insert(cleanedKeywords, newKwObj)
															seen[cleanKw] = true
														end
													end
												end
												result.keywords = cleanedKeywords
											end

											local keywordCount = result.keywords and #result.keywords or 0
											local hasTitle = result.title and result.title ~= ""
											local hasCaption = result.caption and result.caption ~= ""
											local hasHeadline = result.headline and result.headline ~= ""
											local hasInstructions = result.instructions and result.instructions ~= ""
											local hasLocation = result.location and result.location ~= ""

											-- Calculate confidence based on metadata completeness
											local metadataFields = { hasTitle, hasCaption, hasHeadline, hasInstructions, hasLocation }
											local filledFields = 0
											for _, hasField in ipairs( metadataFields ) do
												if hasField then filledFields = filledFields + 1 end
											end
											local confidence = (filledFields / #metadataFields) * 0.7 + (math.min(keywordCount, 10) / 10) * 0.3
											
											trace( "completed in %.03f sec, got %d keywords, title: %s, caption: %s, headline: %s, instructions: %s, location: %s, confidence: %.2f",
												elapsed, keywordCount,
												hasTitle and "yes" or "no",
												hasCaption and "yes" or "no",
												hasHeadline and "yes" or "no",
												hasInstructions and "yes" or "no",
												hasLocation and "yes" or "no",
												confidence )
											completedResults[ i ] = {
												photo = photo,
												keywords = result.keywords,
												title = result.title,
												caption = result.caption,
												headline = result.headline,
												instructions = result.instructions,
												copyright = result.copyright,
												location = result.location,
												elapsed = elapsed,
												confidence = confidence,
											}
											propertyTable[ propConsumedTime ] = propertyTable[ propConsumedTime ] + elapsed
											propertyTable[ propElapsedTime ] = LrDate.currentTime() - propertyTable[ propStartTime ]

											-- Update progress to show completion
											if not (progressScope:isCanceled() or progressScope:isDone()) then
												progressScope:setCaption( LOC( "$$$/AiTagger/ProgressComplete=Completed: ^1 (^2 of ^3)", fileName, i, totalThumbnails ) )
												progressScope:setPortionComplete( i, totalThumbnails )
											end
										else
											-- Update progress to show error
											if not (progressScope:isCanceled() or progressScope:isDone()) then
												progressScope:setCaption( LOC( "$$$/AiTagger/ProgressError=Error analyzing ^1 (^2 of ^3)", fileName, i, totalThumbnails ) )
											end

											-- Store placeholder with empty fields to keep array dense
											completedResults[ i ] = {
												photo = photo,
												keywords = {},
												title = "",
												caption = result.message or "Analysis failed",
												headline = "",
												instructions = "",
												copyright = "",
												location = "",
												elapsed = elapsed,
												confidence = 0,
											}

											-- Collect error instead of showing modal dialog
											table.insert( processingErrors, { fileName = fileName, message = result.message, type = "analysis" } )
										end

										runningTasks = runningTasks - 1
										trace( "end analysis" )
							end)
						end
					)

					LrTasks.yield()
				end

				while runningTasks > 0 do
					LrTasks.sleep( 0.2 )
				end
				progressScope:done()

				-- Assign all results to propPhotos at once to avoid sparse array issues
				-- (async tasks may complete out of order, which would create holes in the array
				-- and cause undefined behavior with Lua 5.1's # operator)
				propertyTable[ propPhotos ] = completedResults

				logger:tracef( "done analyzing %d photos in %.02f sec (%.02f sec elapsed)", #photos, propertyTable[ propConsumedTime ], propertyTable[ propElapsedTime ] )

				-- Now that analysis is complete, show the results dialog
				if not progressScope:isCanceled() then
					-- Set final completion message
					progressScope:setCaption( LOC( "$$$/AiTagger/ProgressFinished=Analysis complete! Opening results..." ) )
					progressScope:setPortionComplete( 1, 1 )
					-- Brief pause to let user see completion message
					LrTasks.sleep( 0.5 )

					-- Show error summary if there were any processing errors
					if #processingErrors > 0 then
						local errorMessage = string.format("Processing completed with %d error(s):\n\n", #processingErrors)
						for i, error in ipairs(processingErrors) do
							errorMessage = errorMessage .. string.format("%d. %s: %s\n", i, error.fileName, error.message)
						end
						LrDialogs.message("Processing Errors", errorMessage, "warning")
					end

					-- Ensure first photo is selected before showing dialog
					if #propertyTable[ propPhotos ] > 0 and propertyTable[ propCurrentPhotoIndex ] == 0 then
						logger:tracef( "setting initial photo selection: totalPhotos=%d, photosArrayLength=%d",
							propertyTable[ propTotalPhotos ], #propertyTable[ propPhotos ] )
						propertyTable[ propCurrentPhotoIndex ] = 1
						loadPhoto( propertyTable, 1 )
					end

					showResponse( propertyTable )
				end

				progressScope:done()
			end

		end
	)
end

--------------------------------------------------------------------------------
-- Begin the search
AiTagger()
